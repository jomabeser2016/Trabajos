﻿using System;
using System.Runtime.Serialization;
using SAT.Libreria.Model;

namespace SAT.SAF.Model.GA.RecursosHumanos.DatosSolicitudDescansoFisico
{
    [DataContract]
    public class ConceptoSolicitud : Pagina
    {
        [DataMember]
        public string CODI_PARAM_DFI { get; set;}
        [DataMember]
        public string NOM_PARAM_DFI { get; set; }
        [DataMember]
        public string ESTA_PARAM_DFI { get; set; }
        [DataMember]
        public string QRY_PARAM_DFI { get; set; }
        [DataMember]    
        public string MSJ_PARAM_DFI { get; set; }
        [DataMember]
        public int VAL1_PARAM_DFI { get; set; }
        [DataMember]
        public string USER_PARAM_DFI { get; set; }
        [DataMember]
        public DateTime FECH_PARAM_DFI { get; set; }
    }
}
