﻿using System.Runtime.Serialization;
using SAT.Libreria.Model;

namespace SAT.SAF.Model.GA.RecursosHumanos.DatosSolicitudDescansoFisico
{
    [DataContract]
    public class ValidaMovimiento : Pagina
    {
        [DataMember]
        public string PERFIL_USU { get; set; }
        [DataMember]
        public string ESTADO_INI { get; set; }
        [DataMember]
        public string ESTADO_FIN { get; set; }
        [DataMember]
        public string RESULTADO_CONS { get; set; }
        [DataMember]
        public string MENSAJE_CONS { get; set; }
    }
}
