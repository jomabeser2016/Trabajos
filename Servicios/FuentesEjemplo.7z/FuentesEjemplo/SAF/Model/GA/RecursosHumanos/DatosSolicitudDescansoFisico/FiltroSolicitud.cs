﻿using System.Runtime.Serialization;
using SAT.Libreria.Model;

namespace SAT.SAF.Model.GA.RecursosHumanos.DatosSolicitudDescansoFisico
{
    [DataContract]
    public class FiltroSolicitud : Pagina
    {
        [DataMember]
        public string CODI_DEPE_TDE { get; set; }
        [DataMember]
        public string TIPO_PLAN_TPL { get; set; }
        [DataMember]
        public string CODI_NIVE_TNI { get; set; }
        [DataMember]
        public string CODI_EST_DDF { get; set; }
        [DataMember]
        public string PERI_GENE_DFI { get; set; }
        [DataMember]
        public string PERI_GENE_DDF { get; set; }
        [DataMember]
        public string CODI_EMPL_PER { get; set; }
        [DataMember]
        public int NUM_FILA { get; set; } 
    }
}
