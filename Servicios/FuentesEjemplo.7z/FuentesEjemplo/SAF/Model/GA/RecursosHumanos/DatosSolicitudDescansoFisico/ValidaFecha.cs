﻿using System;
using System.Runtime.Serialization;
using SAT.Libreria.Model;

namespace SAT.SAF.Model.GA.RecursosHumanos.DatosSolicitudDescansoFisico
{
    [DataContract]
    public class ValidaFecha : Pagina
    {
        [DataMember]
        public DateTime FECHA_INI { get; set; }
        [DataMember]
        public DateTime FECHA_FIN { get; set; }
        [DataMember]
        public string RESULTADO_CONS { get; set; }
        [DataMember]
        public string MENSAJE_CONS { get; set; }
    }
}
