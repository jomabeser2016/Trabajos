﻿using System;
using System.Runtime.Serialization;
using SAT.Libreria.Model;

namespace SAT.SAF.Model.GA.RecursosHumanos.SolicitudDescansoFisico
{
    [DataContract]
    public class DatosTrabajador : Pagina
    {
        [DataMember]
        public string TIPO_PLAN_TPL { get; set; }
        [DataMember]
        public string DESC_TIPO_TPL { get; set; }
        [DataMember]
        public string CODI_EMPL_PER { get; set; }
        [DataMember]
        public string NOMB_CORT_PER  { get; set; }
        [DataMember]
        public DateTime FECH_INGR_PER { get; set; }
        [DataMember]
        public string LIBR_ELEC_PER { get; set; }
        [DataMember]
        public string MODA_LABO_PER { get; set; }
        [DataMember]
        public string ABRE_LABO_PER { get; set; }
        [DataMember]
        public string DESC_LABO_PER  { get; set; }
        [DataMember]
        public string CODI_SEDE_SED { get; set; }
        [DataMember]
        public string DESC_SEDE_SED { get; set; }
        [DataMember]
        public string CODI_DEPE_TDE { get; set; }
        [DataMember]
        public string DESC_LARG_TDE { get; set; }
        [DataMember]
        public string UBI_FISI_TDE { get; set; }
        [DataMember]
        public string DESC_FISI_TDE { get; set; }
        [DataMember]
        public string CODI_NIVE_TNI { get; set; }
        [DataMember]
        public string NOMB_PUES_TNI { get; set; }
        [DataMember]
        public string CODI_CARG_TCA { get; set; }
        [DataMember]
        public string DESC_CARG_TCA { get; set; }
        [DataMember]
        public string NIVE_CARG_PER { get; set; }
        
    }
}
