﻿using System;
using System.Runtime.Serialization;
using SAT.Libreria.Model;

namespace SAT.SAF.Model.GA.RecursosHumanos.SolicitudDescansoFisico
{
    [DataContract]
    public class SolicitudDescansoFisico : Pagina
    {
        [DataMember]
        public string TIPO_PLAN_TPL { get; set; }
        [DataMember]
        public string CODI_EMPL_PER { get; set; }
        [DataMember]
        public string ANIO_GENE_DFI { get; set; }
        [DataMember]
        public string ESTA_ANIO_DFI { get; set; }
        [DataMember]
        public string PERI_GENE_DFI { get; set; }
        [DataMember]
        public int DIAS_GENE_DFI { get; set; }
        [DataMember]
        public int DIAS_PROG_DFI { get; set; }
        [DataMember]
        public int DIAS_XPROG_DFI { get; set; }
        [DataMember]
        public int DIAS_GOZA_DFI { get; set; }
        [DataMember]
        public DateTime FECH_REGI_DFI { get; set; }
        [DataMember]
        public string USER_REGI_DFI { get; set; }
        [DataMember]
        public DateTime FECH_ACTU_DFI { get; set; }
        [DataMember]
        public string USER_ACTU_DFI { get; set; }
    }
}
