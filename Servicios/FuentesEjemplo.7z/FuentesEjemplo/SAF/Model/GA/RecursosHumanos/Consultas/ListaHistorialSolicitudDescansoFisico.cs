﻿using System;
using System.Runtime.Serialization;
using SAT.Libreria.Model;

namespace SAT.SAF.Model.GA.RecursosHumanos.Consultas
{
    [DataContract]
    public class ListaHistorialSolicitudDescansoFisico : Pagina
    {
        [DataMember]
        public string TIPO_PLAN_TPL { get; set; }
        [DataMember]
        public string CODI_EMPL_PER { get; set; }
        [DataMember]
        public string NOMB_EMPL_PER { get; set; }
        [DataMember]
        public string NOMB_EST_DDF { get; set; }
        [DataMember]
        public string ANIO_GENE_DFI { get; set; }
        [DataMember]
        public string PERI_GENE_DDF { get; set; }
        [DataMember]
        public int SECU_PROG_DDF { get; set; }
        [DataMember]
        public DateTime INIC_PROG_DDF { get; set; }
        [DataMember]
        public DateTime FINA_PROG_DDF { get; set; }
        [DataMember]
        public int DIAS_PROG_DDF { get; set; }
        [DataMember]
        public DateTime FECH_REGI_DDF { get; set; }
        [DataMember]
        public string USER_REGI_DDF { get; set; }
        [DataMember]
        public string OBSE_REGI_DDF { get; set; }
        [DataMember]
        public DateTime FECH_ACTU_DDF { get; set; }
        [DataMember]
        public string USER_ACTU_DDF { get; set; }
        [DataMember]
        public string OBSE_ACTU_DDF { get; set; }
    }
}
