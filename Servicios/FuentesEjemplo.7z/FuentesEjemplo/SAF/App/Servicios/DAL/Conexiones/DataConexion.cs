﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SAT.Libreria.EnterpriseLibrary.DataAccessApplicationBlock.Oracle;

using Oracle.ManagedDataAccess.Client;

namespace SAT.SAF.App.Servicios.DAL.Conexiones
{
    public class DataConexion
    {
        private OracleConnection oracleConnection;
        private OracleTransaction oracleTransaction;

        public OracleConnection Conexion
        {
            get { return oracleConnection; }
            set { oracleConnection = value; }
        }

        public DataConexion(string aplicativo)
        {
            oracleConnection = DatabaseFactory.CrearConexion("", aplicativo);

            oracleConnection.Open();
        }

        public void BeginTransaction()
        {
            oracleTransaction = oracleConnection.BeginTransaction(IsolationLevel.ReadCommitted);
        }

        public void Commit()
        {
            oracleTransaction.Commit();
        }

        public void Rollback()
        {
            oracleTransaction.Rollback();
        }

        public void Cerrar()
        {
            if (oracleTransaction != null)
            {
                oracleTransaction.Dispose();
            }

            if (oracleConnection != null)
            {
                oracleConnection.Close();
                oracleConnection.Dispose();
            }
        }
    }
}
