﻿using System.Collections.Generic;
using Oracle.ManagedDataAccess.Client;
using SAT.Libreria.Model;
using SAT.SAF.Model.GA.RecursosHumanos.DatosSolicitudDescansoFisico;
using SAT.SAF.Model.GA.RecursosHumanos.SolicitudDescansoFisico;
using SAT.SAF.Model.GA.RecursosHumanos.Consultas;

using SAT.SAF.App.Servicios.DAL.Conexiones;

namespace SAT.SAF.App.Servicios.DAL.GA.RecursosHumanos
{
    public interface ISolicitudDescansoFisicoDAL
    {
        //LISTAS
        List<SolicitudDescansoFisico> DevolverSolicitudDescansoFisico(FiltroSolicitud Fil, DataConexion cn);
        List<ListaDetalleSolicitudDescansoFisico> DevolverDetalleSolicitudDescansoFisico(FiltroSolicitud Fil, DataConexion cn);
        List<DetalleSolicitudDescansoFisico> DevolverFilaDetalleSolicitudDescansoFisico(FiltroSolicitud Fil, DataConexion cn);
        List<ListaHistorialSolicitudDescansoFisico> DevolverHistDetalleSolicitudDescansoFisico(FiltroSolicitud Fil, DataConexion cn);
        //RESULTADOS
        void RegistrarDescansoFisico(FiltroSolicitud Fil, DataConexion cn);
        void RegistrarDetalleDescansoFisico(List<DetalleSolicitudDescansoFisico> Det, DataConexion cn);
        void ActualizarDetalleDescansoFisico(List<DetalleSolicitudDescansoFisico> Det, DataConexion cn);
    }
}
