﻿using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Text;
using Oracle.ManagedDataAccess.Client;

using SAT.Libreria.Model;
using SAT.Libreria.EnterpriseLibrary.DataAccessApplicationBlock.Oracle;

using SAT.SAF.App.Servicios.DAL.Conexiones;

using SAT.SAF.Model.GA.RecursosHumanos.DatosSolicitudDescansoFisico;
using SAT.SAF.Model.GA.RecursosHumanos.SolicitudDescansoFisico;
using SAT.SAF.Model.GA.RecursosHumanos.Consultas;

namespace SAT.SAF.App.Servicios.DAL.GA.RecursosHumanos
{
    public class SolicitudDescansoFisicoDAL : ISolicitudDescansoFisicoDAL
    {
        #region Constantes

        private const string KSTR_NOMBRE_ESQUEMA = "EsquemaBD";
        #endregion
   
        public List<SolicitudDescansoFisico> DevolverSolicitudDescansoFisico(FiltroSolicitud Fil, DataConexion cn)
        {
            List<SolicitudDescansoFisico> objLst = new List<SolicitudDescansoFisico>();

            try
            {
                string strEsquemaBD = ConfigurationManager.AppSettings[KSTR_NOMBRE_ESQUEMA].ToString();
                using (OracleCommand cmd = new OracleCommand(strEsquemaBD + ".PKG_PER_INTRA_SOL_DES_FIS_TB.PER_INTRA_GET_DESC_FIS"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("AS_TIPO_PLAN", OracleDbType.Char).Value = Fil.TIPO_PLAN_TPL;
                    cmd.Parameters.Add("AS_CODI_EMPL", OracleDbType.Char).Value = Fil.CODI_EMPL_PER;
                    cmd.Parameters.Add("TDESC_FIS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    OracleDataReader objReader = DatabaseFactory.ExecuteReader(cmd, cn.Conexion);

                    while (objReader.Read())
                    {
                        var obj = new SolicitudDescansoFisico();

                         obj.TIPO_PLAN_TPL = objReader.GetString(0);
                        obj.CODI_EMPL_PER = objReader.GetString(1);
                        obj.ANIO_GENE_DFI = objReader.GetString(2);
                        obj.ESTA_ANIO_DFI = objReader.GetString(3);
                        obj.PERI_GENE_DFI = objReader.GetString(4);
                        obj.DIAS_GENE_DFI = objReader.GetInt32(5);
                        obj.DIAS_PROG_DFI = objReader.GetInt32(6);
                        obj.DIAS_XPROG_DFI = objReader.GetInt32(7);
                        obj.DIAS_GOZA_DFI = objReader.GetInt32(8);
                        obj.FECH_REGI_DFI = objReader.GetDateTime(9);
                        obj.USER_REGI_DFI = objReader.GetString(10);
                        obj.FECH_ACTU_DFI = objReader.GetDateTime(11);
                        obj.USER_ACTU_DFI = objReader.GetString(12);

                        objLst.Add(obj);
                    }

                }
            }
            catch
            {
                throw;
            }
            return objLst;
        }
        public List<ListaDetalleSolicitudDescansoFisico> DevolverDetalleSolicitudDescansoFisico(FiltroSolicitud Fil, DataConexion cn)
        {
            List<ListaDetalleSolicitudDescansoFisico> objLst = new List<ListaDetalleSolicitudDescansoFisico>();
            try
            {
                string strEsquemaBD = ConfigurationManager.AppSettings[KSTR_NOMBRE_ESQUEMA].ToString();
                using (OracleCommand cmd = new OracleCommand(strEsquemaBD + ".PKG_PER_INTRA_SOL_DES_FIS_TB.PER_INTRA_GET_DET_DESC_FIS"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("AS_TIPO_PLAN", OracleDbType.Char).Value = Fil.TIPO_PLAN_TPL;
                    cmd.Parameters.Add("AS_CODI_EMPL", OracleDbType.Char).Value = Fil.CODI_EMPL_PER;
                    cmd.Parameters.Add("AS_ANIO_DFI", OracleDbType.Char).Value = Fil.PERI_GENE_DFI;
                    cmd.Parameters.Add("AS_TDEPEN", OracleDbType.Char).Value = Fil.CODI_DEPE_TDE;
                    cmd.Parameters.Add("AS_TCAR", OracleDbType.Char).Value = Fil.CODI_NIVE_TNI;
                    cmd.Parameters.Add("AS_EST", OracleDbType.Char).Value = Fil.CODI_EST_DDF;
                    cmd.Parameters.Add("AS_PER_DDF", OracleDbType.Char).Value = Fil.PERI_GENE_DDF;
                    cmd.Parameters.Add("TDET_DESC_FIS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    OracleDataReader objReader = DatabaseFactory.ExecuteReader(cmd, cn.Conexion);

                    while (objReader.Read())
                    {
                        var obj = new ListaDetalleSolicitudDescansoFisico();
                        obj.SortColumn = "";
                        obj.SortOrder = "";
                        obj.TIPO_PLAN_TPL = objReader.GetString(0);
                        obj.ANIO_GENE_DFI = objReader.GetString(8);
                        obj.CODI_EMPL_PER = objReader.GetString(2);
                        obj.SECU_PROG_DDF = objReader.GetInt32(9); 
                        obj.NOMB_EMPL_PER = objReader.GetString(3);
                        obj.DESC_PLAN_TPL = objReader.GetString(1);
                        obj.DESC_DEPE_TDE = objReader.GetString(5);
                        obj.NOMB_PUES_TNI = objReader.GetString(7);
                        obj.CODI_EST_DDF = objReader.GetString(10);
                        obj.NOMB_EST_DDF = objReader.GetString(11);
                        obj.INIC_PROG_DDF = objReader.GetDateTime(12);
                        obj.FINA_PROG_DDF = objReader.GetDateTime(13);
                        obj.DIAS_PROG_DDF = objReader.GetInt32(14);
                        obj.OBSE_REGI_DDF = objReader.GetString(17);
                        obj.OBSE_ACTU_DDF = objReader.GetString(20);
                        obj.PERI_GENE_DDF = objReader.GetString(21);
                        obj.CADE_SOLI_DFI = objReader.GetString(22);
                        objLst.Add(obj);
                    }
                }
            }
            catch
            {
                throw;
            }
            return objLst;
        }
        public List<DetalleSolicitudDescansoFisico> DevolverFilaDetalleSolicitudDescansoFisico(FiltroSolicitud Fil, DataConexion cn)
        {
            List<DetalleSolicitudDescansoFisico> objLst = new List<DetalleSolicitudDescansoFisico>();
            try
            {
                string strEsquemaBD = ConfigurationManager.AppSettings[KSTR_NOMBRE_ESQUEMA].ToString();
                using (OracleCommand cmd = new OracleCommand(strEsquemaBD + ".PKG_PER_INTRA_SOL_DES_FIS_TB.PER_INTRA_GET_FIL_DET_DESC_FIS"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("AS_TIPO_PLAN", OracleDbType.Char).Value = Fil.TIPO_PLAN_TPL;
                    cmd.Parameters.Add("AS_CODI_EMPL", OracleDbType.Char).Value = Fil.CODI_EMPL_PER;
                    cmd.Parameters.Add("AS_ANIO_DFI", OracleDbType.Char).Value = Fil.PERI_GENE_DFI;
                    cmd.Parameters.Add("AS_FILA", OracleDbType.Int32).Value = Fil.NUM_FILA;
                    cmd.Parameters.Add("TFIL_DESC_FIS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    OracleDataReader objReader = DatabaseFactory.ExecuteReader(cmd, cn.Conexion);

                    while (objReader.Read())
                    {
                        var obj = new DetalleSolicitudDescansoFisico();
                        obj.TIPO_PLAN_TPL = objReader.GetString(0);
                        obj.CODI_EMPL_PER = objReader.GetString(2);
                        obj.ANIO_GENE_DFI = objReader.GetString(8);
                        obj.SECU_PROG_DDF = objReader.GetInt32(9);
                        obj.CODI_EST_DDF = objReader.GetString(10);
                        obj.INIC_PROG_DDF = objReader.GetDateTime(12);
                        obj.FINA_PROG_DDF = objReader.GetDateTime(13);
                        obj.DIAS_PROG_DDF = objReader.GetInt32(14);
                        obj.FECH_REGI_DDF = objReader.GetDateTime(15);
                        obj.USER_REGI_DDF = objReader.GetString(16);
                        obj.OBSE_REGI_DDF = objReader.GetString(17);
                        obj.FECH_ACTU_DDF = objReader.GetDateTime(18);
                        obj.USER_ACTU_DDF = objReader.GetString(19);
                        obj.OBSE_ACTU_DDF = objReader.GetString(20);

                        objLst.Add(obj);
                    }
                }
            }
            catch
            {
                throw;
            }
            return objLst;
        }
        public List<ListaHistorialSolicitudDescansoFisico> DevolverHistDetalleSolicitudDescansoFisico(FiltroSolicitud Fil, DataConexion cn)
        {
            List<ListaHistorialSolicitudDescansoFisico> objLst = new List<ListaHistorialSolicitudDescansoFisico>();
            try
            {
                string strEsquemaBD = ConfigurationManager.AppSettings[KSTR_NOMBRE_ESQUEMA].ToString();
                using (OracleCommand cmd = new OracleCommand(strEsquemaBD + ".PKG_PER_INTRA_SOL_DES_FIS_TB.PER_INTRA_GET_HIS_DET_DESC_FIS"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("AS_TIPO_PLAN", OracleDbType.Char).Value = Fil.TIPO_PLAN_TPL;
                    cmd.Parameters.Add("AS_CODI_EMPL", OracleDbType.Char).Value = Fil.CODI_EMPL_PER;
                    cmd.Parameters.Add("AS_ANIO_DFI", OracleDbType.Char).Value = Fil.PERI_GENE_DFI;
                    cmd.Parameters.Add("AS_FILA", OracleDbType.Int32).Value = Fil.NUM_FILA;
                    cmd.Parameters.Add("THIS_DESC_FIS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    OracleDataReader objReader = DatabaseFactory.ExecuteReader(cmd, cn.Conexion);

                    while (objReader.Read())
                    {
                        var obj = new ListaHistorialSolicitudDescansoFisico();
                        obj.TIPO_PLAN_TPL = objReader.GetString(0);
                        obj.CODI_EMPL_PER = objReader.GetString(1);
                        obj.NOMB_EMPL_PER = objReader.GetString(2);
                        obj.NOMB_EST_DDF = objReader.GetString(3);
                        obj.ANIO_GENE_DFI = objReader.GetString(4);
                        obj.PERI_GENE_DDF = objReader.GetString(5);
                        obj.SECU_PROG_DDF = objReader.GetInt32(6);
                        obj.INIC_PROG_DDF = objReader.GetDateTime(7);
                        obj.FINA_PROG_DDF = objReader.GetDateTime(8);
                        obj.DIAS_PROG_DDF = objReader.GetInt32(9);
                        obj.FECH_REGI_DDF = objReader.GetDateTime(10);
                        obj.USER_REGI_DDF = objReader.GetString(11);
                        obj.OBSE_REGI_DDF = objReader.GetString(12);
                        obj.FECH_ACTU_DDF = objReader.GetDateTime(13);
                        obj.USER_ACTU_DDF = objReader.GetString(14);
                        obj.OBSE_ACTU_DDF = objReader.GetString(15);

                        objLst.Add(obj);
                    }
                }
            }
            catch
            {
                throw;
            }
            return objLst;
        }
        public void RegistrarDescansoFisico(FiltroSolicitud Fil, DataConexion cn)
        {
            try
            {
                string strEsquemaBD = ConfigurationManager.AppSettings[KSTR_NOMBRE_ESQUEMA].ToString();
                using (OracleCommand cmd = new OracleCommand(strEsquemaBD + ".PKG_PER_INTRA_SOL_DES_FIS_TB.PER_INTRA_INS_DESC_FIS"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("AS_TIPO_PLAN", OracleDbType.Char).Value = Fil.TIPO_PLAN_TPL;
                    cmd.Parameters.Add("AS_CODI_EMPL", OracleDbType.Char).Value = Fil.CODI_EMPL_PER;

                    DatabaseFactory.Execute(cmd, cn.Conexion);
                }
            }
            catch
            {
                throw;
            }
        }
        public void RegistrarDetalleDescansoFisico(List<DetalleSolicitudDescansoFisico> Det, DataConexion cn)
        {
            try
            {
                StringBuilder strXml = new StringBuilder(SAT.Libreria.Archivos.Xml.KSTR_ENCODING_UTF8);
                strXml.Append("<detalle_sol_desc_fis>");

                foreach (DetalleSolicitudDescansoFisico objLst in Det)
                {
                    strXml.Append("<row>");
                    strXml.Append("<tipo_plan_tpl>");
                    strXml.Append(objLst.TIPO_PLAN_TPL);
                    strXml.Append("</tipo_plan_tpl>");
                    strXml.Append("<codi_empl_per>");
                    strXml.Append(objLst.CODI_EMPL_PER);
                    strXml.Append("</codi_empl_per>");
                    strXml.Append("<anio_gene_dfi>");
                    strXml.Append(objLst.ANIO_GENE_DFI);
                    strXml.Append("</anio_gene_dfi>");
                    strXml.Append("<secu_prog_ddf>");
                    strXml.Append(objLst.SECU_PROG_DDF);
                    strXml.Append("</secu_prog_ddf>");
                    strXml.Append("<codi_est_ddf>");
                    strXml.Append(objLst.CODI_EST_DDF);
                    strXml.Append("</codi_est_ddf>");
                    strXml.Append("<inic_prog_ddf>");
                    strXml.Append(objLst.INIC_PROG_DDF.ToShortDateString());
                    strXml.Append("</inic_prog_ddf>");
                    strXml.Append("<fina_prog_ddf>");
                    strXml.Append(objLst.FINA_PROG_DDF.ToShortDateString());
                    strXml.Append("</fina_prog_ddf>");
                    strXml.Append("<dias_prog_ddf>");
                    strXml.Append(objLst.DIAS_PROG_DDF);
                    strXml.Append("</dias_prog_ddf>");
                    strXml.Append("<fech_regi_ddf>");
                    strXml.Append(objLst.FECH_REGI_DDF.ToShortDateString());
                    strXml.Append("</fech_regi_ddf>");
                    strXml.Append("<user_regi_ddf>");
                    strXml.Append(objLst.CODI_EMPL_PER);
                    strXml.Append("</user_regi_ddf>");
                    strXml.Append("<obse_regi_ddf>");
                    strXml.Append(objLst.OBSE_REGI_DDF);
                    strXml.Append("</obse_regi_ddf>");
                    strXml.Append("<fech_actu_ddf>");
                    strXml.Append(objLst.FECH_ACTU_DDF.ToShortDateString());
                    strXml.Append("</fech_actu_ddf>");
                    strXml.Append("<user_actu_ddf>");
                    strXml.Append(objLst.CODI_EMPL_PER);
                    strXml.Append("</user_actu_ddf>");
                    strXml.Append("<obse_actu_ddf>");
                    strXml.Append(objLst.OBSE_ACTU_DDF);
                    strXml.Append("</obse_actu_ddf>");
                    strXml.Append("</row>");
                }
                strXml.Append("</detalle_sol_desc_fis>");

                string strEsquemaBD = ConfigurationManager.AppSettings[KSTR_NOMBRE_ESQUEMA].ToString();
                using (OracleCommand cmd = new OracleCommand(strEsquemaBD + ".PKG_PER_INTRA_SOL_DES_FIS_TB.PER_INTRA_INS_DET_DESC_FIS_XML"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("AS_XML", OracleDbType.Varchar2).Value = strXml.ToString();

                    DatabaseFactory.Execute(cmd, cn.Conexion);
                }
            }
            catch
            {
                throw;
            }
        }
        public void ActualizarDetalleDescansoFisico(List<DetalleSolicitudDescansoFisico> Det, DataConexion cn)
        {
            try
            {
                StringBuilder strXml = new StringBuilder(SAT.Libreria.Archivos.Xml.KSTR_ENCODING_UTF8);
                strXml.Append("<detalle_sol_desc_fis>");

                foreach (DetalleSolicitudDescansoFisico objLst in Det)
                {
                    strXml.Append("<row>");
                    strXml.Append("<tipo_plan_tpl>");
                    strXml.Append(objLst.TIPO_PLAN_TPL);
                    strXml.Append("</tipo_plan_tpl>");
                    strXml.Append("<codi_empl_per>");
                    strXml.Append(objLst.CODI_EMPL_PER);
                    strXml.Append("</codi_empl_per>");
                    strXml.Append("<anio_gene_dfi>");
                    strXml.Append(objLst.ANIO_GENE_DFI);
                    strXml.Append("</anio_gene_dfi>");
                    strXml.Append("<secu_prog_ddf>");
                    strXml.Append(objLst.SECU_PROG_DDF);
                    strXml.Append("</secu_prog_ddf>");
                    strXml.Append("<codi_est_ddf>");
                    strXml.Append(objLst.CODI_EST_DDF);
                    strXml.Append("</codi_est_ddf>");
                    strXml.Append("<inic_prog_ddf>");
                    strXml.Append(objLst.INIC_PROG_DDF.ToShortDateString());
                    strXml.Append("</inic_prog_ddf>");
                    strXml.Append("<fina_prog_ddf>");
                    strXml.Append(objLst.FINA_PROG_DDF.ToShortDateString());
                    strXml.Append("</fina_prog_ddf>");
                    strXml.Append("<dias_prog_ddf>");
                    strXml.Append(objLst.DIAS_PROG_DDF);
                    strXml.Append("</dias_prog_ddf>");
                    strXml.Append("<fech_regi_ddf>");
                    strXml.Append(objLst.FECH_REGI_DDF.ToShortDateString());
                    strXml.Append("</fech_regi_ddf>");
                    strXml.Append("<user_regi_ddf>");
                    strXml.Append(objLst.CODI_EMPL_PER);
                    strXml.Append("</user_regi_ddf>");
                    strXml.Append("<obse_regi_ddf>");
                    strXml.Append(objLst.OBSE_REGI_DDF);
                    strXml.Append("</obse_regi_ddf>");
                    strXml.Append("<fech_actu_ddf>");
                    strXml.Append(objLst.FECH_ACTU_DDF.ToShortDateString());
                    strXml.Append("</fech_actu_ddf>");
                    strXml.Append("<user_actu_ddf>");
                    strXml.Append(objLst.CODI_EMPL_PER);
                    strXml.Append("</user_actu_ddf>");
                    strXml.Append("<obse_actu_ddf>");
                    strXml.Append(objLst.OBSE_ACTU_DDF);
                    strXml.Append("</obse_actu_ddf>");
                    strXml.Append("</row>");
                }
                strXml.Append("</detalle_sol_desc_fis>");

                string strEsquemaBD = ConfigurationManager.AppSettings[KSTR_NOMBRE_ESQUEMA].ToString();
                using (OracleCommand cmd = new OracleCommand(strEsquemaBD + ".PKG_PER_INTRA_SOL_DES_FIS_TB.PER_INTRA_UPD_DESC_FIS_XML"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("AS_XML", OracleDbType.Varchar2).Value = strXml.ToString();

                    DatabaseFactory.Execute(cmd, cn.Conexion);
                }
            }
            catch
            {
                throw;
            }
        }
    }
}
