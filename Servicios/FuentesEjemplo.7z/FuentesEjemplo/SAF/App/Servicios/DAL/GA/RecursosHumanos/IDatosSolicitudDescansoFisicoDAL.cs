﻿using System.Collections.Generic;
using Oracle.ManagedDataAccess.Client;
using SAT.Libreria.Model;
using SAT.SAF.Model.GA.RecursosHumanos.DatosSolicitudDescansoFisico;
using SAT.SAF.Model.GA.RecursosHumanos.SolicitudDescansoFisico;

using SAT.SAF.App.Servicios.DAL.Conexiones;

namespace SAT.SAF.App.Servicios.DAL.GA.RecursosHumanos
{
    public interface IDatosSolicitudDescansoFisicoDAL
    {
        //LISTAS
        List<DatosTrabajador> DevolverDatosTrabajador(FiltroSolicitud Fil, DataConexion cn);
        List<ItemSelectList> DevolverDatosFiltroDependencia(DataConexion cn);
        List<ItemSelectList> DevolverDatosFiltroPlanilla(DataConexion cn);
        List<ItemSelectList> DevolverDatosFiltroCargo(DataConexion cn);
        List<ItemSelectList> DevolverDatosFiltroEstadoSolicitud(DataConexion cn);
        List<ItemSelectList> DevolverDatosFiltroPeriodoGeneracion(FiltroSolicitud Fil, DataConexion cn);
        List<ItemSelectList> DevolverDatosFiltroPeriodoSolicitud(FiltroSolicitud Fil, DataConexion cn);
        List<ItemSelectList> DevolverDatosFiltroTrabajador(FiltroSolicitud Fil, DataConexion cn);
        List<ConceptoSolicitud> DevolverDatosConceptoSolicitud(DataConexion cn);
        List<ConceptoSolicitud> DevolverFilDatosConceptoSolicitud(ConceptoSolicitud Sol, DataConexion cn);
        List<ValidaFecha> ValidarFechasSolicitudDescansoFisico(ValidaFecha Dat, DataConexion cn);
        List<ValidaMovimiento> ValidarMovSolicitudDescansoFisico(ValidaMovimiento Dat, DataConexion cn);
        //RESULTADOS
        void RegistrarConceptoSolicitud(ConceptoSolicitud Sol, DataConexion cn);
        void ActualizarConceptoSolicitud(ConceptoSolicitud Sol, DataConexion cn);
    }
}
