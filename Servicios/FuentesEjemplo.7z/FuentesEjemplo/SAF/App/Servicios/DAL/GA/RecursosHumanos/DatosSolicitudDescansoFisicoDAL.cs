﻿using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Text;

using Oracle.ManagedDataAccess.Client;

using SAT.Libreria.EnterpriseLibrary.DataAccessApplicationBlock.Oracle;
using SAT.Libreria.Model;

using SAT.SAF.App.Servicios.DAL.Conexiones;

using SAT.SAF.Model.GA.RecursosHumanos.DatosSolicitudDescansoFisico;
using SAT.SAF.Model.GA.RecursosHumanos.SolicitudDescansoFisico;

namespace SAT.SAF.App.Servicios.DAL.GA.RecursosHumanos
{
    public class DatosSolicitudDescansoFisicoDAL : IDatosSolicitudDescansoFisicoDAL
    {
        #region Constantes

        private const string KSTR_NOMBRE_ESQUEMA = "EsquemaBD";
        #endregion
        public List<DatosTrabajador> DevolverDatosTrabajador(FiltroSolicitud Fil, DataConexion cn)
        {
            List<DatosTrabajador> objLst = new List<DatosTrabajador>();
            try
            {
                string strEsquemaBD = ConfigurationManager.AppSettings[KSTR_NOMBRE_ESQUEMA].ToString();
                using (OracleCommand cmd = new OracleCommand(strEsquemaBD + ".PKG_PER_INTRA_SOL_DES_FIS_TB.PER_INTRA_GET_DAT_PER"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("AS_CODI_EMPL", OracleDbType.Char).Value = Fil.CODI_EMPL_PER;
                    cmd.Parameters.Add("TDAT_PER", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    OracleDataReader objReader = DatabaseFactory.ExecuteReader(cmd, cn.Conexion);

                    while (objReader.Read())
                    {
                        var obj = new DatosTrabajador();
                        obj.TIPO_PLAN_TPL = objReader.GetString(0);
                        obj.DESC_TIPO_TPL = objReader.GetString(1);
                        obj.CODI_EMPL_PER = objReader.GetString(2);
                        obj.NOMB_CORT_PER = objReader.GetString(3);
                        obj.FECH_INGR_PER = objReader.GetDateTime(4);
                        obj.LIBR_ELEC_PER = objReader.GetString(5);
                        obj.MODA_LABO_PER = objReader.GetString(6);
                        obj.ABRE_LABO_PER = objReader.GetString(7);
                        obj.DESC_LABO_PER = objReader.GetString(8);
                        obj.CODI_SEDE_SED = objReader.GetString(9);
                        obj.DESC_SEDE_SED = objReader.GetString(10);
                        obj.CODI_DEPE_TDE = objReader.GetString(11);
                        obj.DESC_LARG_TDE = objReader.GetString(12);
                        obj.UBI_FISI_TDE = objReader.GetString(13);
                        obj.DESC_FISI_TDE = objReader.GetString(14);
                        obj.CODI_NIVE_TNI = objReader.GetString(15);
                        obj.NOMB_PUES_TNI = objReader.GetString(16);
                        obj.CODI_CARG_TCA = objReader.GetString(17);
                        obj.DESC_CARG_TCA = objReader.GetString(18);
                        obj.NIVE_CARG_PER = objReader.GetString(19);

                        objLst.Add(obj);
                    }

                }
            }
            catch
            {
                throw;
            }
            return objLst;
        }
        public List<ItemSelectList> DevolverDatosFiltroDependencia(DataConexion cn)
        {
            List<ItemSelectList> objLst = new List<ItemSelectList>();

            try
            {
                string strEsquemaBD = ConfigurationManager.AppSettings[KSTR_NOMBRE_ESQUEMA].ToString();
                using (OracleCommand cmd = new OracleCommand(strEsquemaBD + ".PKG_PER_INTRA_SOL_DES_FIS_TS.PER_INTRA_TDEPENDENCIA"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("TDEPENDENCIA", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    OracleDataReader objReader = DatabaseFactory.ExecuteReader(cmd, cn.Conexion);

                    while (objReader.Read())
                    {
                        var obj = new ItemSelectList();
                        obj.Valor = objReader.GetString(0);
                        obj.Texto = objReader.GetString(1);

                        objLst.Add(obj);
                    }
                }
            }
            catch
            {
                throw;
            }
            return objLst;
        }
        public List<ItemSelectList> DevolverDatosFiltroPlanilla(DataConexion cn)
        {
            List<ItemSelectList> objLst = new List<ItemSelectList>();

            try
            {
                string strEsquemaBD = ConfigurationManager.AppSettings[KSTR_NOMBRE_ESQUEMA].ToString();
                using (OracleCommand cmd = new OracleCommand(strEsquemaBD + ".PKG_PER_INTRA_SOL_DES_FIS_TS.PER_INTRA_TPLANILLA"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("TPLANILLA", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    OracleDataReader objReader = DatabaseFactory.ExecuteReader(cmd, cn.Conexion);

                    while (objReader.Read())
                    {
                        var obj = new ItemSelectList();
                        obj.Valor = objReader.GetString(0);
                        obj.Texto = objReader.GetString(1);

                        objLst.Add(obj);
                    }
                }
            }
            catch
            {
                throw;
            }
            return objLst;
        }
        public List<ItemSelectList> DevolverDatosFiltroCargo(DataConexion cn)
        {
            List<ItemSelectList> objLst = new List<ItemSelectList>();

            try
            {
                string strEsquemaBD = ConfigurationManager.AppSettings[KSTR_NOMBRE_ESQUEMA].ToString();
                using (OracleCommand cmd = new OracleCommand(strEsquemaBD + ".PKG_PER_INTRA_SOL_DES_FIS_TS.PER_INTRA_TNIVEL"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("TNIVEL", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    OracleDataReader objReader = DatabaseFactory.ExecuteReader(cmd, cn.Conexion);

                    while (objReader.Read())
                    {
                        var obj = new ItemSelectList();
                        obj.Valor = objReader.GetString(0);
                        obj.Texto = objReader.GetString(1);

                        objLst.Add(obj);
                    }
                }
            }
            catch
            {
                throw;
            }
            return objLst;
        }
        public List<ItemSelectList> DevolverDatosFiltroEstadoSolicitud(DataConexion cn)
        {
            List<ItemSelectList> objLst = new List<ItemSelectList>();

            try
            {
                string strEsquemaBD = ConfigurationManager.AppSettings[KSTR_NOMBRE_ESQUEMA].ToString();
                using (OracleCommand cmd = new OracleCommand(strEsquemaBD + ".PKG_PER_INTRA_SOL_DES_FIS_TS.PER_INTRA_TEST_SOLICITUD"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("TEST_SOLICITUD", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    OracleDataReader objReader = DatabaseFactory.ExecuteReader(cmd, cn.Conexion);

                    while (objReader.Read())
                    {
                        var obj = new ItemSelectList();
                        obj.Valor = objReader.GetString(0);
                        obj.Texto = objReader.GetString(1);

                        objLst.Add(obj);
                    }
                }
            }
            catch
            {
                throw;
            }
            return objLst;
        }
        public List<ItemSelectList> DevolverDatosFiltroPeriodoGeneracion(FiltroSolicitud Fil, DataConexion cn)
        {
            List<ItemSelectList> objLst = new List<ItemSelectList>();

            try
            {
                string strEsquemaBD = ConfigurationManager.AppSettings[KSTR_NOMBRE_ESQUEMA].ToString();
                using (OracleCommand cmd = new OracleCommand(strEsquemaBD + ".PKG_PER_INTRA_SOL_DES_FIS_TS.PER_INTRA_TPERIODO_DFI"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("AS_TIPO_PLAN", OracleDbType.Char).Value = Fil.TIPO_PLAN_TPL;
                    cmd.Parameters.Add("AS_TDEPEN", OracleDbType.Char).Value = Fil.CODI_DEPE_TDE;
                    cmd.Parameters.Add("AS_TCAR", OracleDbType.Char).Value = Fil.CODI_NIVE_TNI;
                    cmd.Parameters.Add("AS_EST", OracleDbType.Char).Value = Fil.CODI_EST_DDF;
                    cmd.Parameters.Add("TPERIODO_DFI", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    OracleDataReader objReader = DatabaseFactory.ExecuteReader(cmd, cn.Conexion);

                    while (objReader.Read())
                    {
                        var obj = new ItemSelectList();
                        obj.Valor = objReader.GetString(0);
                        obj.Texto = objReader.GetString(0);
                        objLst.Add(obj);
                    }
                }
            }
            catch
            {
                throw;
            }
            return objLst;
        }
        public List<ItemSelectList> DevolverDatosFiltroPeriodoSolicitud(FiltroSolicitud Fil, DataConexion cn)
        {
            List<ItemSelectList> objLst = new List<ItemSelectList>();

            try
            {
                string strEsquemaBD = ConfigurationManager.AppSettings[KSTR_NOMBRE_ESQUEMA].ToString();
                using (OracleCommand cmd = new OracleCommand(strEsquemaBD + ".PKG_PER_INTRA_SOL_DES_FIS_TS.PER_INTRA_TPERIODO_DDF"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("AS_TIPO_PLAN", OracleDbType.Char).Value = Fil.TIPO_PLAN_TPL;
                    cmd.Parameters.Add("AS_TDEPEN", OracleDbType.Char).Value = Fil.CODI_DEPE_TDE;
                    cmd.Parameters.Add("AS_TCAR", OracleDbType.Char).Value = Fil.CODI_NIVE_TNI;
                    cmd.Parameters.Add("AS_EST", OracleDbType.Char).Value = Fil.CODI_EST_DDF;
                    cmd.Parameters.Add("AS_ANIO_DFI", OracleDbType.Char).Value = Fil.PERI_GENE_DFI;
                    cmd.Parameters.Add("TPERIODO_DDF", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    OracleDataReader objReader = DatabaseFactory.ExecuteReader(cmd, cn.Conexion);

                    while (objReader.Read())
                    {
                        var obj = new ItemSelectList();
                        obj.Valor = objReader.GetString(0);
                        obj.Texto = objReader.GetString(0);
                        objLst.Add(obj);
                    }
                }
            }
            catch
            {
                throw;
            }
            return objLst;
        }
        public List<ItemSelectList> DevolverDatosFiltroTrabajador(FiltroSolicitud Fil, DataConexion cn)
        {
            List<ItemSelectList> objLst = new List<ItemSelectList>();

            try
            {
                string strEsquemaBD = ConfigurationManager.AppSettings[KSTR_NOMBRE_ESQUEMA].ToString();
                using (OracleCommand cmd = new OracleCommand(strEsquemaBD + ".PKG_PER_INTRA_SOL_DES_FIS_TS.PER_INTRA_TTRABAJADOR"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("AS_TIPO_PLAN", OracleDbType.Char).Value = Fil.TIPO_PLAN_TPL;
                    cmd.Parameters.Add("AS_TDEPEN", OracleDbType.Char).Value = Fil.CODI_DEPE_TDE;
                    cmd.Parameters.Add("AS_TCAR", OracleDbType.Char).Value = Fil.CODI_NIVE_TNI;
                    cmd.Parameters.Add("AS_EST", OracleDbType.Char).Value = Fil.CODI_EST_DDF;
                    cmd.Parameters.Add("AS_ANIO_DFI", OracleDbType.Char).Value = Fil.PERI_GENE_DFI;
                    cmd.Parameters.Add("AS_PER_DDF", OracleDbType.Char).Value = Fil.PERI_GENE_DDF;
                    cmd.Parameters.Add("TTRABAJADOR", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    OracleDataReader objReader = DatabaseFactory.ExecuteReader(cmd, cn.Conexion);

                    while (objReader.Read())
                    {
                        var obj = new ItemSelectList();
                        obj.Valor = objReader.GetString(0);
                        obj.Texto = objReader.GetString(1);
                        objLst.Add(obj);
                    }
                }
            }
            catch
            {
                throw;
            }

            return objLst;
        }
        public List<ConceptoSolicitud> DevolverDatosConceptoSolicitud(DataConexion cn)
        {
            List<ConceptoSolicitud> objLst = new List<ConceptoSolicitud>();
            try
            {
                string strEsquemaBD = ConfigurationManager.AppSettings[KSTR_NOMBRE_ESQUEMA].ToString();
                using (OracleCommand cmd = new OracleCommand(strEsquemaBD + ".PKG_PER_INTRA_SOL_DES_FIS_TS.PER_INTRA_GET_CONCEPTOS"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("TCONCEPTOS", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    OracleDataReader objReader = DatabaseFactory.ExecuteReader(cmd, cn.Conexion);

                    while (objReader.Read())
                    {
                        var obj = new ConceptoSolicitud();
                        obj.CODI_PARAM_DFI = objReader.GetString(0);
                        obj.NOM_PARAM_DFI = objReader.GetString(1);
                        obj.ESTA_PARAM_DFI = objReader.GetString(2);
                        obj.QRY_PARAM_DFI = objReader.GetString(3);
                        obj.MSJ_PARAM_DFI = objReader.GetString(4);
                        obj.VAL1_PARAM_DFI = objReader.GetInt32(5);
                        obj.USER_PARAM_DFI = objReader.GetString(6);
                        obj.FECH_PARAM_DFI = objReader.GetDateTime(7);
                        objLst.Add(obj);
                    }
                }
            }
            catch
            {
                throw;
            }

            return objLst;
        }
        public List<ConceptoSolicitud> DevolverFilDatosConceptoSolicitud(ConceptoSolicitud Sol, DataConexion cn)
        {
            List<ConceptoSolicitud> objLst = new List<ConceptoSolicitud>();
            try
            {
                string strEsquemaBD = ConfigurationManager.AppSettings[KSTR_NOMBRE_ESQUEMA].ToString();
                using (OracleCommand cmd = new OracleCommand(strEsquemaBD + ".PKG_PER_INTRA_SOL_DES_FIS_TS.PER_INTRA_GET_FIL_CONCEPTO"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("CODI_PARAM_DFI", OracleDbType.Char).Value = Sol.CODI_PARAM_DFI;
                    cmd.Parameters.Add("TCONCEPTO", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    OracleDataReader objReader = DatabaseFactory.ExecuteReader(cmd, cn.Conexion);

                    while (objReader.Read())
                    {
                        var obj = new ConceptoSolicitud();
                        obj.CODI_PARAM_DFI = objReader.GetString(0);
                        obj.NOM_PARAM_DFI = objReader.GetString(1);
                        obj.ESTA_PARAM_DFI = objReader.GetString(2);
                        obj.QRY_PARAM_DFI = objReader.GetString(3);
                        obj.MSJ_PARAM_DFI = objReader.GetString(4);
                        obj.VAL1_PARAM_DFI = objReader.GetInt32(5);
                        obj.USER_PARAM_DFI = objReader.GetString(6);
                        obj.FECH_PARAM_DFI = objReader.GetDateTime(7);
                        objLst.Add(obj);
                    }
                }
            }
            catch
            {
                throw;
            }

            return objLst;
        }
        public List<ValidaFecha> ValidarFechasSolicitudDescansoFisico(ValidaFecha Dat, DataConexion cn)
        {
            List<ValidaFecha> objLst = new List<ValidaFecha>();
            try
            {
                string strEsquemaBD = ConfigurationManager.AppSettings[KSTR_NOMBRE_ESQUEMA].ToString();
                using (OracleCommand cmd = new OracleCommand(strEsquemaBD + ".PKG_PER_INTRA_SOL_DES_FIS_TS.PER_INTRA_VAL_FEC"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("AS_FEC_INI", OracleDbType.Date).Value = Dat.FECHA_INI;
                    cmd.Parameters.Add("AS_FEC_FIN", OracleDbType.Date).Value = Dat.FECHA_FIN;
                    cmd.Parameters.Add("T_RESUL", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    OracleDataReader objReader = DatabaseFactory.ExecuteReader(cmd, cn.Conexion);

                    while (objReader.Read())
                    {
                        var obj = new ValidaFecha();
                        obj.RESULTADO_CONS = objReader.GetString(0);
                        obj.MENSAJE_CONS = objReader.GetString(1);

                        objLst.Add(obj);
                    }
                }
            }
            catch
            {
                throw;
            }

            return objLst;
        }
        public List<ValidaMovimiento> ValidarMovSolicitudDescansoFisico(ValidaMovimiento Dat, DataConexion cn)
        {
            List<ValidaMovimiento> objLst = new List<ValidaMovimiento>();
            try
            {
                string strEsquemaBD = ConfigurationManager.AppSettings[KSTR_NOMBRE_ESQUEMA].ToString();
                using (OracleCommand cmd = new OracleCommand(strEsquemaBD + ".PKG_PER_INTRA_SOL_DES_FIS_TS.PER_INTRA_VAL_MOV"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("AS_PERFIL", OracleDbType.Date).Value = Dat.PERFIL_USU;
                    cmd.Parameters.Add("AS_EST_INI", OracleDbType.Date).Value = Dat.ESTADO_INI;
                    cmd.Parameters.Add("AS_EST_FIN", OracleDbType.Date).Value = Dat.ESTADO_FIN;
                    cmd.Parameters.Add("T_RESUL", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    OracleDataReader objReader = DatabaseFactory.ExecuteReader(cmd, cn.Conexion);

                    while (objReader.Read())
                    {
                        var obj = new ValidaMovimiento();
                        obj.RESULTADO_CONS = objReader.GetString(0);
                        obj.MENSAJE_CONS = objReader.GetString(1);

                        objLst.Add(obj);
                    }
                }
            }
            catch
            {
                throw;
            }

            return objLst;
        }
        public void RegistrarConceptoSolicitud(ConceptoSolicitud Sol, DataConexion cn)
        {
            try
            {
                string strEsquemaBD = ConfigurationManager.AppSettings[KSTR_NOMBRE_ESQUEMA].ToString();
                using (OracleCommand cmd = new OracleCommand(strEsquemaBD + ".PKG_PER_INTRA_SOL_DES_FIS_TS.PER_INTRA_INS_CONCEPTO"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("CODI_PARAM_DFI", OracleDbType.Char).Value = Sol.CODI_PARAM_DFI;
                    cmd.Parameters.Add("NOM_PARAM_DFI", OracleDbType.Char).Value = Sol.NOM_PARAM_DFI;
                    cmd.Parameters.Add("ESTA_PARAM_DFI", OracleDbType.Char).Value = Sol.ESTA_PARAM_DFI;
                    cmd.Parameters.Add("QRY_PARAM_DFI", OracleDbType.Char).Value = Sol.QRY_PARAM_DFI;
                    cmd.Parameters.Add("MSJ_PARAM_DFI", OracleDbType.Char).Value = Sol.MSJ_PARAM_DFI;
                    cmd.Parameters.Add("VAL1_PARAM_DFI", OracleDbType.Int32).Value = Sol.VAL1_PARAM_DFI;
                    cmd.Parameters.Add("USER_PARAM_DFI", OracleDbType.Char).Value = Sol.USER_PARAM_DFI;
                    cmd.Parameters.Add("FECH_PARAM_DFI", OracleDbType.Date).Value = Sol.FECH_PARAM_DFI;

                    DatabaseFactory.Execute(cmd, cn.Conexion);
                }
            }
            catch
            {
                throw;
            }
        }
        public void ActualizarConceptoSolicitud(ConceptoSolicitud Sol, DataConexion cn)
        {
            try
            {
                string strEsquemaBD = ConfigurationManager.AppSettings[KSTR_NOMBRE_ESQUEMA].ToString();
                using (OracleCommand cmd = new OracleCommand(strEsquemaBD + ".PKG_PER_INTRA_SOL_DES_FIS_TS.PER_INTRA_UPD_CONCEPTO"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("CODI_PARAM_DFI", OracleDbType.Char).Value = Sol.CODI_PARAM_DFI;
                    cmd.Parameters.Add("NOM_PARAM_DFI", OracleDbType.Char).Value = Sol.NOM_PARAM_DFI;
                    cmd.Parameters.Add("ESTA_PARAM_DFI", OracleDbType.Char).Value = Sol.ESTA_PARAM_DFI;
                    cmd.Parameters.Add("QRY_PARAM_DFI", OracleDbType.Char).Value = Sol.QRY_PARAM_DFI;
                    cmd.Parameters.Add("MSJ_PARAM_DFI", OracleDbType.Char).Value = Sol.MSJ_PARAM_DFI;
                    cmd.Parameters.Add("VAL1_PARAM_DFI", OracleDbType.Int32).Value = Sol.VAL1_PARAM_DFI;
                    cmd.Parameters.Add("USER_PARAM_DFI", OracleDbType.Char).Value = Sol.USER_PARAM_DFI;
                    cmd.Parameters.Add("FECH_PARAM_DFI", OracleDbType.Date).Value = Sol.FECH_PARAM_DFI;

                    DatabaseFactory.Execute(cmd, cn.Conexion);
                }
            }
            catch
            {
                throw;
            }
        }
    }
}
