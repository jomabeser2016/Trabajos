﻿using System;
using System.Collections.Generic;
using System.Text;

using SAT.Libreria.Model;
using SAT.SAF.Model.GA.RecursosHumanos.DatosSolicitudDescansoFisico;
using SAT.SAF.Model.GA.RecursosHumanos.SolicitudDescansoFisico;
using SAT.SAF.Model.GA.RecursosHumanos.Consultas;

using SAT.SAF.App.Servicios.DAL.Conexiones;
using SAT.SAF.App.Servicios.DAL.GA.RecursosHumanos;

namespace SAT.SAF.App.Servicios.BLL.GA.RecursosHumanos
{
    public class SolicitudDescansoFisicoBLL
    {
         #region Constantes
        private const string KSTR_NOMBRE_APP_PERSONAL = "RecursosHumanos";
        #endregion

        ISolicitudDescansoFisicoDAL SolicitudDescansoFisicoDAL;

        public SolicitudDescansoFisicoBLL()
        {
            this.SolicitudDescansoFisicoDAL = new SolicitudDescansoFisicoDAL();
        }

        public SolicitudDescansoFisicoBLL(ISolicitudDescansoFisicoDAL SolicitudDescansoFisicoDAL)
        {
            this.SolicitudDescansoFisicoDAL = SolicitudDescansoFisicoDAL;
        }
               
        public List<SolicitudDescansoFisico> DevolverSolicitudDescansoFisico(FiltroSolicitud Fil)
        {
            try
            {
                List<SolicitudDescansoFisico> objLst = new List<SolicitudDescansoFisico>();

                DataConexion conn = new DataConexion(KSTR_NOMBRE_APP_PERSONAL);

                try
                {
                    objLst = SolicitudDescansoFisicoDAL.DevolverSolicitudDescansoFisico(Fil, conn);
                }
                catch
                {
                    throw;
                }
                finally
                {
                    conn.Cerrar();
                }

                return objLst;
            }
            catch
            {
                throw;
            }
        }
        public List<ListaDetalleSolicitudDescansoFisico> DevolverDetalleSolicitudDescansoFisico(FiltroSolicitud Fil)
        {
            try
            {
                List<ListaDetalleSolicitudDescansoFisico> objLst = new List<ListaDetalleSolicitudDescansoFisico>();

                DataConexion conn = new DataConexion(KSTR_NOMBRE_APP_PERSONAL);

                try
                {
                    objLst = SolicitudDescansoFisicoDAL.DevolverDetalleSolicitudDescansoFisico(Fil, conn);
                }
                catch
                {
                    throw;
                }
                finally
                {
                    conn.Cerrar();
                }

                return objLst;
            }
            catch
            {
                throw;
            }
        }
        public List<DetalleSolicitudDescansoFisico> DevolverFilaDetalleSolicitudDescansoFisico(FiltroSolicitud Fil)
        {
            try
            {
                List<DetalleSolicitudDescansoFisico> objLst = new List<DetalleSolicitudDescansoFisico>();

                DataConexion conn = new DataConexion(KSTR_NOMBRE_APP_PERSONAL);

                try
                {
                    objLst = SolicitudDescansoFisicoDAL.DevolverFilaDetalleSolicitudDescansoFisico(Fil, conn);
                }
                catch
                {
                    throw;
                }
                finally
                {
                    conn.Cerrar();
                }

                return objLst;
            }
            catch
            {
                throw;
            }
        }
        public List<ListaHistorialSolicitudDescansoFisico> DevolverHistDetalleSolicitudDescansoFisico(FiltroSolicitud Fil)
        {
            try
            {
                List<ListaHistorialSolicitudDescansoFisico> objLst = new List<ListaHistorialSolicitudDescansoFisico>();

                DataConexion conn = new DataConexion(KSTR_NOMBRE_APP_PERSONAL);

                try
                {
                    objLst = SolicitudDescansoFisicoDAL.DevolverHistDetalleSolicitudDescansoFisico(Fil, conn);
                }
                catch
                {
                    throw;
                }
                finally
                {
                    conn.Cerrar();
                }

                return objLst;
            }
            catch
            {
                throw;
            }
        }
        public void RegistrarDescansoFisico(FiltroSolicitud Fil)
        {            
            try
            {
                DataConexion conn = new DataConexion(KSTR_NOMBRE_APP_PERSONAL);

                conn.BeginTransaction();

                try
                {
                    SolicitudDescansoFisicoDAL.RegistrarDescansoFisico(Fil, conn);
                    conn.Commit();
                }
                catch
                {
                    conn.Rollback();
                    throw;
                }
                finally 
                {
                    conn.Cerrar();
                }
            }
            catch
            {
                throw;
            }
        }
        public void RegistrarDetalleDescansoFisico(List<DetalleSolicitudDescansoFisico> Det)
        {
            try
            {
                DataConexion conn = new DataConexion(KSTR_NOMBRE_APP_PERSONAL);

                conn.BeginTransaction();

                try
                {
                    SolicitudDescansoFisicoDAL.RegistrarDetalleDescansoFisico(Det, conn);
                    conn.Commit();
                }
                catch
                {
                    conn.Rollback();
                    throw;
                }
                finally
                {
                    conn.Cerrar();
                }
            }
            catch
            {
                throw;
            }
        }
        public void ActualizarDetalleDescansoFisico(List<DetalleSolicitudDescansoFisico> Det)
        {
            try
            {
                DataConexion conn = new DataConexion(KSTR_NOMBRE_APP_PERSONAL);

                conn.BeginTransaction();

                try
                {
                    SolicitudDescansoFisicoDAL.ActualizarDetalleDescansoFisico(Det, conn);
                    conn.Commit();

                }
                catch
                {
                    conn.Rollback();
                    throw;
                }
                finally
                {
                    conn.Cerrar();
                }
            }
            catch
            {
                throw;
            }
        }
       
    }
}
