﻿using System;
using System.Collections.Generic;
using System.Text;

using SAT.Libreria.Model;

using SAT.SAF.Model.GA.RecursosHumanos.DatosSolicitudDescansoFisico;
using SAT.SAF.Model.GA.RecursosHumanos.SolicitudDescansoFisico;

using SAT.SAF.App.Servicios.DAL.Conexiones;
using SAT.SAF.App.Servicios.DAL.GA.RecursosHumanos;

namespace SAT.SAF.App.Servicios.BLL.GA.RecursosHumanos
{
    public class DatosSolicitudDescansoFisicoBLL
    {
        #region Constantes
        private const string KSTR_NOMBRE_APP_PERSONAL = "RecursosHumanos";
        #endregion

        IDatosSolicitudDescansoFisicoDAL DatosSolicitudDescansoFisicoDAL;

        public DatosSolicitudDescansoFisicoBLL()
        {
            this.DatosSolicitudDescansoFisicoDAL = new DatosSolicitudDescansoFisicoDAL();
        }

        public DatosSolicitudDescansoFisicoBLL(IDatosSolicitudDescansoFisicoDAL DatosSolicitudDescansoFisicoDAL)
        {
            this.DatosSolicitudDescansoFisicoDAL = DatosSolicitudDescansoFisicoDAL;
        }

        public List<DatosTrabajador> DevolverDatosTrabajador(FiltroSolicitud Fil)
        {
            try
            {
                List<DatosTrabajador> objLst = new List<DatosTrabajador>();

                DataConexion conn = new DataConexion(KSTR_NOMBRE_APP_PERSONAL);

                try
                {
                    objLst = DatosSolicitudDescansoFisicoDAL.DevolverDatosTrabajador(Fil, conn);
                }
                catch
                {
                    throw;
                }
                finally
                {
                    conn.Cerrar();
                }

                return objLst;
            }
            catch
            {
                throw;
            }
        }
        
        public List<ItemSelectList> DevolverDatosFiltroDependencia()
        {
            try
            {
                List<ItemSelectList> objLst = new List<ItemSelectList>();

                DataConexion conn = new DataConexion(KSTR_NOMBRE_APP_PERSONAL);

                try
                {
                    objLst = DatosSolicitudDescansoFisicoDAL.DevolverDatosFiltroDependencia(conn);
                }
                catch
                {
                    throw;
                }
                finally
                {
                    conn.Cerrar();
                }

                return objLst;

            }
            catch
            {
                throw;
            }
        }
        
        public List<ItemSelectList> DevolverDatosFiltroPlanilla()
        {
            try
            {
                List<ItemSelectList> objLst = new List<ItemSelectList>();

                DataConexion conn = new DataConexion(KSTR_NOMBRE_APP_PERSONAL);

                try
                {
                    objLst = DatosSolicitudDescansoFisicoDAL.DevolverDatosFiltroPlanilla(conn);
                }
                catch
                {
                    throw;
                }
                finally
                {
                    conn.Cerrar();
                }

                return objLst;

            }
            catch
            {
                throw;
            }
        }
        
        public List<ItemSelectList> DevolverDatosFiltroCargo()
        {
            try
            {
                List<ItemSelectList> objLst = new List<ItemSelectList>();

                DataConexion conn = new DataConexion(KSTR_NOMBRE_APP_PERSONAL);

                try
                {
                    objLst = DatosSolicitudDescansoFisicoDAL.DevolverDatosFiltroCargo(conn);
                }
                catch
                {
                    throw;
                }
                finally
                {
                    conn.Cerrar();
                }

                return objLst;

            }
            catch
            {
                throw;
            }
        }
        
        public List<ItemSelectList> DevolverDatosFiltroEstadoSolicitud()
        {
            try
            {
                List<ItemSelectList> objLst = new List<ItemSelectList>();

                DataConexion conn = new DataConexion(KSTR_NOMBRE_APP_PERSONAL);

                try
                {
                    objLst = DatosSolicitudDescansoFisicoDAL.DevolverDatosFiltroEstadoSolicitud(conn);
                }
                catch
                {
                    throw;
                }
                finally
                {
                    conn.Cerrar();
                }

                return objLst;

            }
            catch
            {
                throw;
            }
        }
        
        public List<ItemSelectList> DevolverDatosFiltroPeriodoGeneracion(FiltroSolicitud Fil)
        {
            try
            {
                List<ItemSelectList> objLst = new List<ItemSelectList>();

                DataConexion conn = new DataConexion(KSTR_NOMBRE_APP_PERSONAL);

                try
                {
                    objLst = DatosSolicitudDescansoFisicoDAL.DevolverDatosFiltroPeriodoGeneracion(Fil, conn);
                }
                catch
                {
                    throw;
                }
                finally
                {
                    conn.Cerrar();
                }

                return objLst;

            }
            catch
            {
                throw;
            }
        }
        
        public List<ItemSelectList> DevolverDatosFiltroPeriodoSolicitud(FiltroSolicitud Fil)
        {
            try
            {
                List<ItemSelectList> objLst = new List<ItemSelectList>();

                DataConexion conn = new DataConexion(KSTR_NOMBRE_APP_PERSONAL);

                try
                {
                    objLst = DatosSolicitudDescansoFisicoDAL.DevolverDatosFiltroPeriodoSolicitud(Fil, conn);
                }
                catch
                {
                    throw;
                }
                finally
                {
                    conn.Cerrar();
                }

                return objLst;

            }
            catch
            {
                throw;
            }
        }
        
        public List<ItemSelectList> DevolverDatosFiltroTrabajador(FiltroSolicitud Fil)
        {
            try
            {
                List<ItemSelectList> objLst = new List<ItemSelectList>();

                DataConexion conn = new DataConexion(KSTR_NOMBRE_APP_PERSONAL);

                try
                {
                    objLst = DatosSolicitudDescansoFisicoDAL.DevolverDatosFiltroTrabajador(Fil, conn);
                }
                catch
                {
                    throw;
                }
                finally
                {
                    conn.Cerrar();
                }

                return objLst;

            }
            catch
            {
                throw;
            }
        }
        
        public List<ConceptoSolicitud> DevolverDatosConceptoSolicitud()
        {
            try
            {
                List<ConceptoSolicitud> objLst = new List<ConceptoSolicitud>();

                DataConexion conn = new DataConexion(KSTR_NOMBRE_APP_PERSONAL);

                try
                {
                    objLst = DatosSolicitudDescansoFisicoDAL.DevolverDatosConceptoSolicitud(conn);
                }
                catch
                {
                    throw;
                }
                finally
                {
                    conn.Cerrar();
                }

                return objLst;
            }
            catch
            {
                throw;
            }
        }
        
        public List<ConceptoSolicitud> DevolverFilDatosConceptoSolicitud(ConceptoSolicitud Sol)
        {
            try
            {
                List<ConceptoSolicitud> objLst = new List<ConceptoSolicitud>();

                DataConexion conn = new DataConexion(KSTR_NOMBRE_APP_PERSONAL);

                try
                {
                    objLst = DatosSolicitudDescansoFisicoDAL.DevolverFilDatosConceptoSolicitud(Sol, conn);
                }
                catch
                {
                    throw;
                }
                finally
                {
                    conn.Cerrar();
                }

                return objLst;
            }
            catch
            {
                throw;
            }
        }
        
        public List<ValidaFecha> ValidarFechasSolicitudDescansoFisico(ValidaFecha Dat)
        {
            try
            {
                List<ValidaFecha> objLst = new List<ValidaFecha>();

                DataConexion conn = new DataConexion(KSTR_NOMBRE_APP_PERSONAL);

                try
                {
                    objLst = DatosSolicitudDescansoFisicoDAL.ValidarFechasSolicitudDescansoFisico(Dat, conn);
                }
                catch
                {
                    throw;
                }
                finally
                {
                    conn.Cerrar();
                }

                return objLst;
            }
            catch
            {
                throw;
            }
        }
        
        public List<ValidaMovimiento> ValidarMovSolicitudDescansoFisico(ValidaMovimiento Dat)
        {
            try
            {
                List<ValidaMovimiento> objLst = new List<ValidaMovimiento>();

                DataConexion conn = new DataConexion(KSTR_NOMBRE_APP_PERSONAL);

                try
                {
                    objLst = DatosSolicitudDescansoFisicoDAL.ValidarMovSolicitudDescansoFisico(Dat, conn);
                }
                catch
                {
                    throw;
                }
                finally
                {
                    conn.Cerrar();
                }

                return objLst;

            }
            catch
            {
                throw;
            }
        }
        
        public void RegistrarConceptoSolicitud(ConceptoSolicitud Sol)
        {
            try
            {
                DataConexion conn = new DataConexion(KSTR_NOMBRE_APP_PERSONAL);
                conn.BeginTransaction();

                try
                {
                    DatosSolicitudDescansoFisicoDAL.RegistrarConceptoSolicitud(Sol, conn);
                    conn.Commit();
                }
                catch
                {
                    conn.Rollback();
                    throw;
                }
                finally
                {
                    conn.Cerrar();
                }
            }
            catch
            {
                throw;
            }
        }
        
        public void ActualizarConceptoSolicitud(ConceptoSolicitud Sol)
        {
            try
            {
                DataConexion conn = new DataConexion(KSTR_NOMBRE_APP_PERSONAL);
                conn.BeginTransaction();

                try
                {
                    DatosSolicitudDescansoFisicoDAL.ActualizarConceptoSolicitud(Sol, conn);
                    conn.Commit();
                }
                catch
                {
                    conn.Rollback();
                    throw;
                }
                finally
                {
                    conn.Cerrar();
                }
            }
            catch
            {
                throw;
            }
        }
    }
}
