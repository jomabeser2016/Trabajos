﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Threading.Tasks;
using SAT.Libreria.Model;
using SAT.SAF.Model.GA.RecursosHumanos.DatosSolicitudDescansoFisico;
using SAT.SAF.Model.GA.RecursosHumanos.SolicitudDescansoFisico;
using SAT.SAF.Model.GA.RecursosHumanos.Consultas;

namespace SAT.SAF.App.Servicios.Contrato.GA.RecursosHumanos
{
    [ServiceContract]
    public interface IServicioGARecursosHumanos
    {
        [OperationContract(Name = "DevolverDatosTrabajador")]
        [WebInvoke(Method = "POST",
                   ResponseFormat = WebMessageFormat.Json,
                   RequestFormat = WebMessageFormat.Json,
                   BodyStyle = WebMessageBodyStyle.Bare,
                   UriTemplate = "DevolverDatosTrabajador")]
        List<DatosTrabajador> DevolverDatosTrabajador(FiltroSolicitud Fil);        

        [OperationContract(Name = "DevolverSolicitudDescansoFisico")]
        [WebInvoke(Method = "POST",
                   ResponseFormat = WebMessageFormat.Json,
                   RequestFormat = WebMessageFormat.Json,
                   BodyStyle = WebMessageBodyStyle.Bare,
                   UriTemplate = "DevolverSolicitudDescansoFisico")]
        List<SolicitudDescansoFisico> DevolverSolicitudDescansoFisico(FiltroSolicitud Fil);

       [OperationContract(Name = "DevolverDetalleSolicitudDescansoFisico")]
       [WebInvoke(Method = "POST",
                  ResponseFormat = WebMessageFormat.Json,
                  RequestFormat = WebMessageFormat.Json,
                  BodyStyle = WebMessageBodyStyle.Bare,
                  UriTemplate = "DevolverDetalleSolicitudDescansoFisico")]
       List<ListaDetalleSolicitudDescansoFisico> DevolverDetalleSolicitudDescansoFisico(FiltroSolicitud Fil);

       [OperationContract(Name = "DevolverFilaDetalleSolicitudDescansoFisico")]
       [WebInvoke(Method = "POST",
                  ResponseFormat = WebMessageFormat.Json,
                  RequestFormat = WebMessageFormat.Json,
                  BodyStyle = WebMessageBodyStyle.Bare,
                  UriTemplate = "DevolverFilaDetalleSolicitudDescansoFisico")]
       List<DetalleSolicitudDescansoFisico> DevolverFilaDetalleSolicitudDescansoFisico(FiltroSolicitud Fil);

       [OperationContract(Name = "DevolverHistDetalleSolicitudDescansoFisico")]
       [WebInvoke(Method = "POST",
                  ResponseFormat = WebMessageFormat.Json,
                  RequestFormat = WebMessageFormat.Json,
                  BodyStyle = WebMessageBodyStyle.Bare,
                  UriTemplate = "DevolverHistDetalleSolicitudDescansoFisico")]
       List<ListaHistorialSolicitudDescansoFisico> DevolverHistDetalleSolicitudDescansoFisico(FiltroSolicitud Fil);

        [OperationContract(Name = "DevolverDatosFiltroDependencia")]
        [WebInvoke(Method = "POST",
                   ResponseFormat = WebMessageFormat.Json,
                   RequestFormat = WebMessageFormat.Json,
                   BodyStyle = WebMessageBodyStyle.Bare,
                   UriTemplate = "DevolverDatosFiltroDependencia")]
        List<ItemSelectList> DevolverDatosFiltroDependencia();

        [OperationContract(Name = "DevolverDatosFiltroPlanilla")]
        [WebInvoke(Method = "POST",
                   ResponseFormat = WebMessageFormat.Json,
                   RequestFormat = WebMessageFormat.Json,
                   BodyStyle = WebMessageBodyStyle.Bare,
                   UriTemplate = "DevolverDatosFiltroPlanilla")]
        List<ItemSelectList> DevolverDatosFiltroPlanilla();

        [OperationContract(Name = "DevolverDatosFiltroCargo")]
        [WebInvoke(Method = "POST",
                   ResponseFormat = WebMessageFormat.Json,
                   RequestFormat = WebMessageFormat.Json,
                   BodyStyle = WebMessageBodyStyle.Bare,
                   UriTemplate = "DevolverDatosFiltroCargo")]
        List<ItemSelectList> DevolverDatosFiltroCargo();

        [OperationContract(Name = "DevolverDatosFiltroEstadoSolicitud")]
        [WebInvoke(Method = "POST",
                   ResponseFormat = WebMessageFormat.Json,
                   RequestFormat = WebMessageFormat.Json,
                   BodyStyle = WebMessageBodyStyle.Bare,
                   UriTemplate = "DevolverDatosFiltroEstadoSolicitud")]
        List<ItemSelectList> DevolverDatosFiltroEstadoSolicitud();

        [OperationContract(Name = "DevolverDatosFiltroPeriodoGeneracion")]
        [WebInvoke(Method = "POST",
                   ResponseFormat = WebMessageFormat.Json,
                   RequestFormat = WebMessageFormat.Json,
                   BodyStyle = WebMessageBodyStyle.Bare,
                   UriTemplate = "DevolverDatosFiltroPeriodoGeneracion")]
        List<ItemSelectList> DevolverDatosFiltroPeriodoGeneracion(FiltroSolicitud Fil);

        [OperationContract(Name = "DevolverDatosFiltroPeriodoSolicitud")]
        [WebInvoke(Method = "POST",
                   ResponseFormat = WebMessageFormat.Json,
                   RequestFormat = WebMessageFormat.Json,
                   BodyStyle = WebMessageBodyStyle.Bare,
                   UriTemplate = "DevolverDatosFiltroPeriodoSolicitud")]
        List<ItemSelectList> DevolverDatosFiltroPeriodoSolicitud(FiltroSolicitud Fil);

        [OperationContract(Name = "DevolverDatosFiltroTrabajador")]
        [WebInvoke(Method = "POST",
                   ResponseFormat = WebMessageFormat.Json,
                   RequestFormat = WebMessageFormat.Json,
                   BodyStyle = WebMessageBodyStyle.Bare,
                   UriTemplate = "DevolverDatosFiltroTrabajador")]
        List<ItemSelectList> DevolverDatosFiltroTrabajador(FiltroSolicitud Fil);

        [OperationContract(Name = "DevolverDatosConceptoSolicitud")]
        [WebInvoke(Method = "POST",
                   ResponseFormat = WebMessageFormat.Json,
                   RequestFormat = WebMessageFormat.Json,
                   BodyStyle = WebMessageBodyStyle.Bare,
                   UriTemplate = "DevolverDatosConceptoSolicitud")]
        List<ConceptoSolicitud> DevolverDatosConceptoSolicitud();

        [OperationContract(Name = "DevolverFilDatosConceptoSolicitud")]
        [WebInvoke(Method = "POST",
                   ResponseFormat = WebMessageFormat.Json,
                   RequestFormat = WebMessageFormat.Json,
                   BodyStyle = WebMessageBodyStyle.Bare,
                   UriTemplate = "DevolverFilDatosConceptoSolicitud")]
        List<ConceptoSolicitud> DevolverFilDatosConceptoSolicitud(ConceptoSolicitud Sol);

        [OperationContract(Name = "ValidarFechasSolicitudDescansoFisico")]
        [WebInvoke(Method = "POST",
                   ResponseFormat = WebMessageFormat.Json,
                   RequestFormat = WebMessageFormat.Json,
                   BodyStyle = WebMessageBodyStyle.Bare,
                   UriTemplate = "ValidarFechasSolicitudDescansoFisico")]
        List<ValidaFecha> ValidarFechasSolicitudDescansoFisico(ValidaFecha Dat);

        [OperationContract(Name = "ValidarMovSolicitudDescansoFisico")]
        [WebInvoke(Method = "POST",
                   ResponseFormat = WebMessageFormat.Json,
                   RequestFormat = WebMessageFormat.Json,
                   BodyStyle = WebMessageBodyStyle.Bare,
                   UriTemplate = "ValidarMovSolicitudDescansoFisico")]
        List<ValidaMovimiento> ValidarMovSolicitudDescansoFisico(ValidaMovimiento Dat);

        [OperationContract(Name = "RegistrarDescansoFisico")]
        [WebInvoke(Method = "POST",
                   ResponseFormat = WebMessageFormat.Json,
                   RequestFormat = WebMessageFormat.Json,
                   BodyStyle = WebMessageBodyStyle.Bare,
                   UriTemplate = "RegistrarDescansoFisico")]
        void RegistrarDescansoFisico(FiltroSolicitud Fil);

        [OperationContract(Name = "RegistrarDetalleDescansoFisico")]
        [WebInvoke(Method = "POST",
                   ResponseFormat = WebMessageFormat.Json,
                   RequestFormat = WebMessageFormat.Json,
                   BodyStyle = WebMessageBodyStyle.Bare,
                   UriTemplate = "RegistrarDetalleDescansoFisico")]
        void RegistrarDetalleDescansoFisico(List<DetalleSolicitudDescansoFisico> Det);

        [OperationContract(Name = "ActualizarDetalleDescansoFisico")]
        [WebInvoke(Method = "POST",
                   ResponseFormat = WebMessageFormat.Json,
                   RequestFormat = WebMessageFormat.Json,
                   BodyStyle = WebMessageBodyStyle.Bare,
                   UriTemplate = "ActualizarDetalleDescansoFisico")]
        void ActualizarDetalleDescansoFisico(List<DetalleSolicitudDescansoFisico> Det);

        [OperationContract(Name = "RegistrarConceptoSolicitud")]
        [WebInvoke(Method = "POST",
                   ResponseFormat = WebMessageFormat.Json,
                   RequestFormat = WebMessageFormat.Json,
                   BodyStyle = WebMessageBodyStyle.Bare,
                   UriTemplate = "RegistrarConceptoSolicitud")]
        void RegistrarConceptoSolicitud(ConceptoSolicitud Sol);

        [OperationContract(Name = "ActualizarConceptoSolicitud")]
        [WebInvoke(Method = "POST",
                   ResponseFormat = WebMessageFormat.Json,
                   RequestFormat = WebMessageFormat.Json,
                   BodyStyle = WebMessageBodyStyle.Bare,
                   UriTemplate = "ActualizarConceptoSolicitud")]
        void ActualizarConceptoSolicitud(ConceptoSolicitud Sol);
    }
}
