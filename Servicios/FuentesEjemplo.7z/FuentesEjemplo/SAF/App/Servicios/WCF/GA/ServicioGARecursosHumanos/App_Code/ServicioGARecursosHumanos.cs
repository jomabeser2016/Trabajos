﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel.Web;
using System.Net;

using SAT.Libreria.Log;
using SAT.Libreria.Model;
using SAT.Libreria.Web.Error;

using SAT.SAF.App.Servicios.Contrato.GA.RecursosHumanos;
using SAT.SAF.Model.GA.RecursosHumanos.DatosSolicitudDescansoFisico;
using SAT.SAF.Model.GA.RecursosHumanos.SolicitudDescansoFisico;
using SAT.SAF.Model.GA.RecursosHumanos.Consultas;
using SAT.SAF.App.Servicios.BLL.GA.RecursosHumanos;

/// <summary>
/// Descripción breve de ServicioGARecursosHumanos
/// </summary>
public class ServicioGARecursosHumanos : IServicioGARecursosHumanos
{
    public List<DatosTrabajador> DevolverDatosTrabajador(FiltroSolicitud Fil)
    {
        try
        {
            Registro.RegistrarLog(NivelLog.Debug, "Invocar método DevolverDatosTrabajador");


            //return new RecursosHumanosBLL().DevolverDatosTrabajador(Fil);
            return new DatosSolicitudDescansoFisicoBLL().DevolverDatosTrabajador(Fil);

        }
        catch (Exception ex)
        {
            Excepcion excepcion = new Excepcion();
            excepcion = ExcepcionWeb.ProcesarExcepcion(ex);

            Registro.RegistrarLog(NivelLog.Error,
                                  excepcion.Identificador,
                                  ex);

            throw new WebFaultException<Excepcion>(excepcion, HttpStatusCode.InternalServerError);            
        }
    }
    public List<SolicitudDescansoFisico> DevolverSolicitudDescansoFisico(FiltroSolicitud Fil)
    {
        try
        {
            Registro.RegistrarLog(NivelLog.Debug, "Invocar método DevolverSolicitudDescansoFisico");


            //return new RecursosHumanosBLL().DevolverSolicitudDescansoFisico(Fil);
            return new SolicitudDescansoFisicoBLL().DevolverSolicitudDescansoFisico(Fil);

        }
        catch (Exception ex)
        {
            Excepcion excepcion = new Excepcion();
            excepcion = ExcepcionWeb.ProcesarExcepcion(ex);

            Registro.RegistrarLog(NivelLog.Error,
                                  excepcion.Identificador,
                                  ex);

            throw new WebFaultException<Excepcion>(excepcion, HttpStatusCode.InternalServerError);  
        }
    }    
    public List<ListaDetalleSolicitudDescansoFisico> DevolverDetalleSolicitudDescansoFisico(FiltroSolicitud Fil)
    {
        try
        {
            Registro.RegistrarLog(NivelLog.Debug, "Invocar método DevolverDetalleSolicitudDescansoFisico");


            //return new RecursosHumanosBLL().DevolverDetalleSolicitudDescansoFisico(Fil);
            return new SolicitudDescansoFisicoBLL().DevolverDetalleSolicitudDescansoFisico(Fil);

        }
        catch (Exception ex)
        {
            Excepcion excepcion = new Excepcion();
            excepcion = ExcepcionWeb.ProcesarExcepcion(ex);

            Registro.RegistrarLog(NivelLog.Error,
                                  excepcion.Identificador,
                                  ex);

            throw new WebFaultException<Excepcion>(excepcion, HttpStatusCode.InternalServerError);  
        }
    }    
    public List<DetalleSolicitudDescansoFisico> DevolverFilaDetalleSolicitudDescansoFisico(FiltroSolicitud Fil)
    {
        try
        {
            Registro.RegistrarLog(NivelLog.Debug, "Invocar método DevolverFilaDetalleSolicitudDescansoFisico");


            //return new RecursosHumanosBLL().DevolverFilaDetalleSolicitudDescansoFisico(Fil);
            return new SolicitudDescansoFisicoBLL().DevolverFilaDetalleSolicitudDescansoFisico(Fil);

        }
        catch (Exception ex)
        {
            Excepcion excepcion = new Excepcion();
            excepcion = ExcepcionWeb.ProcesarExcepcion(ex);

            Registro.RegistrarLog(NivelLog.Error,
                                  excepcion.Identificador,
                                  ex);

            throw new WebFaultException<Excepcion>(excepcion, HttpStatusCode.InternalServerError);  
        }
    }
    public List<ListaHistorialSolicitudDescansoFisico> DevolverHistDetalleSolicitudDescansoFisico(FiltroSolicitud Fil)
    {
        try
        {
            Registro.RegistrarLog(NivelLog.Debug, "Invocar método DevolverHistDetalleSolicitudDescansoFisico");


            //return new RecursosHumanosBLL().DevolverHistDetalleSolicitudDescansoFisico(Fil);
            return new SolicitudDescansoFisicoBLL().DevolverHistDetalleSolicitudDescansoFisico(Fil);

        }
        catch (Exception ex)
        {
            Excepcion excepcion = new Excepcion();
            excepcion = ExcepcionWeb.ProcesarExcepcion(ex);

            Registro.RegistrarLog(NivelLog.Error,
                                  excepcion.Identificador,
                                  ex);

            throw new WebFaultException<Excepcion>(excepcion, HttpStatusCode.InternalServerError);  
        }
    }
    public List<ItemSelectList> DevolverDatosFiltroDependencia()
    {
        try
        {
            Registro.RegistrarLog(NivelLog.Debug, "Invocar método DevolverDatosFiltroDependencia");

            //return new RecursosHumanosBLL().DevolverDatosFiltroDependencia();
            return new DatosSolicitudDescansoFisicoBLL().DevolverDatosFiltroDependencia();

        }
        catch (Exception ex)
        {
            Excepcion excepcion = new Excepcion();
            excepcion = ExcepcionWeb.ProcesarExcepcion(ex);

            Registro.RegistrarLog(NivelLog.Error,
                                  excepcion.Identificador,
                                  ex);

            throw new WebFaultException<Excepcion>(excepcion, HttpStatusCode.InternalServerError);  
        }
    } 
    public List<ItemSelectList> DevolverDatosFiltroPlanilla()
    {
        try
        {
            Registro.RegistrarLog(NivelLog.Debug, "Invocar método DevolverDatosFiltroPlanilla");
            
            //return new RecursosHumanosBLL().DevolverDatosFiltroPlanilla();
            return new DatosSolicitudDescansoFisicoBLL().DevolverDatosFiltroPlanilla();

        }
        catch (Exception ex)
        {
            Excepcion excepcion = new Excepcion();
            excepcion = ExcepcionWeb.ProcesarExcepcion(ex);

            Registro.RegistrarLog(NivelLog.Error,
                                  excepcion.Identificador,
                                  ex);

            throw new WebFaultException<Excepcion>(excepcion, HttpStatusCode.InternalServerError);  
        }
    }
    public List<ItemSelectList> DevolverDatosFiltroCargo()
    {
        try
        {
            Registro.RegistrarLog(NivelLog.Debug, "Invocar método DevolverDatosFiltroCargo");

            //return new RecursosHumanosBLL().DevolverDatosFiltroCargo();
            return new DatosSolicitudDescansoFisicoBLL().DevolverDatosFiltroCargo();

        }
        catch (Exception ex)
        {
            Excepcion excepcion = new Excepcion();
            excepcion = ExcepcionWeb.ProcesarExcepcion(ex);

            Registro.RegistrarLog(NivelLog.Error,
                                  excepcion.Identificador,
                                  ex);

            throw new WebFaultException<Excepcion>(excepcion, HttpStatusCode.InternalServerError);  
        }
    }
    public List<ItemSelectList> DevolverDatosFiltroEstadoSolicitud()
    {
        try
        {
            Registro.RegistrarLog(NivelLog.Debug, "Invocar método DevolverDatosFiltroEstadoSolicitud");

            //return new RecursosHumanosBLL().DevolverDatosFiltroEstadoSolicitud();
            return new DatosSolicitudDescansoFisicoBLL().DevolverDatosFiltroEstadoSolicitud();

        }
        catch (Exception ex)
        {
            Excepcion excepcion = new Excepcion();
            excepcion = ExcepcionWeb.ProcesarExcepcion(ex);

            Registro.RegistrarLog(NivelLog.Error,
                                  excepcion.Identificador,
                                  ex);

            throw new WebFaultException<Excepcion>(excepcion, HttpStatusCode.InternalServerError);  
        }
    }
    public List<ItemSelectList> DevolverDatosFiltroPeriodoGeneracion(FiltroSolicitud Fil)
    {
        try
        {
            Registro.RegistrarLog(NivelLog.Debug, "Invocar método DevolverDatosFiltroPeriodoGeneracion");

            //return new RecursosHumanosBLL().DevolverDatosFiltroPeriodoGeneracion(Fil);
            return new DatosSolicitudDescansoFisicoBLL().DevolverDatosFiltroPeriodoGeneracion(Fil);

        }
        catch (Exception ex)
        {
            Excepcion excepcion = new Excepcion();
            excepcion = ExcepcionWeb.ProcesarExcepcion(ex);

            Registro.RegistrarLog(NivelLog.Error,
                                  excepcion.Identificador,
                                  ex);

            throw new WebFaultException<Excepcion>(excepcion, HttpStatusCode.InternalServerError);  
        }
    } 
    public List<ItemSelectList> DevolverDatosFiltroPeriodoSolicitud(FiltroSolicitud Fil)
    {
        try
        {
            Registro.RegistrarLog(NivelLog.Debug, "Invocar método DevolverDatosFiltroPeriodoSolicitud");

            //return new RecursosHumanosBLL().DevolverDatosFiltroPeriodoSolicitud(Fil);
            return new DatosSolicitudDescansoFisicoBLL().DevolverDatosFiltroPeriodoSolicitud(Fil);

        }
        catch (Exception ex)
        {
            Excepcion excepcion = new Excepcion();
            excepcion = ExcepcionWeb.ProcesarExcepcion(ex);

            Registro.RegistrarLog(NivelLog.Error,
                                  excepcion.Identificador,
                                  ex);

            throw new WebFaultException<Excepcion>(excepcion, HttpStatusCode.InternalServerError);  
        }
    } 
    public List<ItemSelectList> DevolverDatosFiltroTrabajador(FiltroSolicitud Fil)
    {
        try
        {
            Registro.RegistrarLog(NivelLog.Debug, "Invocar método DevolverDatosFiltroTrabajador");

            //return new RecursosHumanosBLL().DevolverDatosFiltroTrabajador(Fil);
            return new DatosSolicitudDescansoFisicoBLL().DevolverDatosFiltroTrabajador(Fil);

        }
        catch (Exception ex)
        {
            Excepcion excepcion = new Excepcion();
            excepcion = ExcepcionWeb.ProcesarExcepcion(ex);

            Registro.RegistrarLog(NivelLog.Error,
                                  excepcion.Identificador,
                                  ex);

            throw new WebFaultException<Excepcion>(excepcion, HttpStatusCode.InternalServerError);  
        }
    }
    public List<ConceptoSolicitud> DevolverDatosConceptoSolicitud()
    {
        try
        {
            Registro.RegistrarLog(NivelLog.Debug, "Invocar método DevolverDatosConceptoSolicitud");

            //return new RecursosHumanosBLL().DevolverDatosConceptoSolicitud();
            return new DatosSolicitudDescansoFisicoBLL().DevolverDatosConceptoSolicitud();

        }
        catch (Exception ex)
        {
            Excepcion excepcion = new Excepcion();
            excepcion = ExcepcionWeb.ProcesarExcepcion(ex);

            Registro.RegistrarLog(NivelLog.Error,
                                  excepcion.Identificador,
                                  ex);

            throw new WebFaultException<Excepcion>(excepcion, HttpStatusCode.InternalServerError);  
        }
    }
    public List<ConceptoSolicitud> DevolverFilDatosConceptoSolicitud(ConceptoSolicitud Sol)
    {
        try
        {
            Registro.RegistrarLog(NivelLog.Debug, "Invocar método DevolverFilDatosConceptoSolicitud");

            //return new RecursosHumanosBLL().DevolverFilDatosConceptoSolicitud(Sol);
            return new DatosSolicitudDescansoFisicoBLL().DevolverFilDatosConceptoSolicitud(Sol);

        }
        catch (Exception ex)
        {
            Excepcion excepcion = new Excepcion();
            excepcion = ExcepcionWeb.ProcesarExcepcion(ex);

            Registro.RegistrarLog(NivelLog.Error,
                                  excepcion.Identificador,
                                  ex);

            throw new WebFaultException<Excepcion>(excepcion, HttpStatusCode.InternalServerError);  
        }
    }
    public List<ValidaFecha> ValidarFechasSolicitudDescansoFisico(ValidaFecha Dat)
    {
        try
        {
            Registro.RegistrarLog(NivelLog.Debug, "Invocar método ValidarFechasSolicitudDescansoFisico");

            //return new RecursosHumanosBLL().ValidarFechasSolicitudDescansoFisico(Dat);
            return new DatosSolicitudDescansoFisicoBLL().ValidarFechasSolicitudDescansoFisico(Dat);

        }
        catch (Exception ex)
        {
            Excepcion excepcion = new Excepcion();
            excepcion = ExcepcionWeb.ProcesarExcepcion(ex);

            Registro.RegistrarLog(NivelLog.Error,
                                  excepcion.Identificador,
                                  ex);

            throw new WebFaultException<Excepcion>(excepcion, HttpStatusCode.InternalServerError);  
        }
    }
    public List<ValidaMovimiento> ValidarMovSolicitudDescansoFisico(ValidaMovimiento Dat)
    {
        try
        {
            Registro.RegistrarLog(NivelLog.Debug, "Invocar método ValidarMovSolicitudDescansoFisico");

            //return new RecursosHumanosBLL().ValidarMovSolicitudDescansoFisico(Dat);
            return new DatosSolicitudDescansoFisicoBLL().ValidarMovSolicitudDescansoFisico(Dat);

        }
        catch (Exception ex)
        {
            Excepcion excepcion = new Excepcion();
            excepcion = ExcepcionWeb.ProcesarExcepcion(ex);

            Registro.RegistrarLog(NivelLog.Error,
                                  excepcion.Identificador,
                                  ex);

            throw new WebFaultException<Excepcion>(excepcion, HttpStatusCode.InternalServerError);  
        }
    }
    public void RegistrarDescansoFisico(FiltroSolicitud Fil)
    {
        try
        {
            Registro.RegistrarLog(NivelLog.Debug, "Invocar metodo RegistrarDescansoFisico");

           //return new RecursosHumanosBLL().RegistrarDescansoFisico(Fil);
            new SolicitudDescansoFisicoBLL().RegistrarDescansoFisico(Fil);
        }
        catch (Exception ex)
        {
            Excepcion excepcion = new Excepcion();
            excepcion = ExcepcionWeb.ProcesarExcepcion(ex);

            Registro.RegistrarLog(NivelLog.Error,
                                  excepcion.Identificador,
                                  ex);

            throw new WebFaultException<Excepcion>(excepcion, HttpStatusCode.InternalServerError);  
        }
    }
    public void RegistrarDetalleDescansoFisico(List<DetalleSolicitudDescansoFisico> Det)
    {
        try
        {
            Registro.RegistrarLog(NivelLog.Debug, "Invocar metodo RegistrarDetalleDescansoFisico");

            //return new RecursosHumanosBLL().RegistrarDetalleDescansoFisico(Det);
            new SolicitudDescansoFisicoBLL().RegistrarDetalleDescansoFisico(Det);

        }
        catch (Exception ex)
        {
            Excepcion excepcion = new Excepcion();
            excepcion = ExcepcionWeb.ProcesarExcepcion(ex);

            Registro.RegistrarLog(NivelLog.Error,
                                  excepcion.Identificador,
                                  ex);

            throw new WebFaultException<Excepcion>(excepcion, HttpStatusCode.InternalServerError);  
        }
    }
    public void ActualizarDetalleDescansoFisico(List<DetalleSolicitudDescansoFisico> Det)
    {
        try
        {
            Registro.RegistrarLog(NivelLog.Debug, "Invocar metodo ActualizarDetalleDescansoFisico");

            //return new RecursosHumanosBLL().ActualizarDetalleDescansoFisico(Det);
            new SolicitudDescansoFisicoBLL().ActualizarDetalleDescansoFisico(Det);
        }
        catch (Exception ex)
        {
            Excepcion excepcion = new Excepcion();
            excepcion = ExcepcionWeb.ProcesarExcepcion(ex);

            Registro.RegistrarLog(NivelLog.Error,
                                  excepcion.Identificador,
                                  ex);

            throw new WebFaultException<Excepcion>(excepcion, HttpStatusCode.InternalServerError);  
        }
    }
    public void RegistrarConceptoSolicitud(ConceptoSolicitud Sol)
    {
        try
        {
            Registro.RegistrarLog(NivelLog.Debug, "Invocar metodo RegistrarConceptoSolicitud");

            //return new RecursosHumanosBLL().RegistrarConceptoSolicitud(Sol);
            new DatosSolicitudDescansoFisicoBLL().RegistrarConceptoSolicitud(Sol);
        }
        catch (Exception ex)
        {
            Excepcion excepcion = new Excepcion();
            excepcion = ExcepcionWeb.ProcesarExcepcion(ex);

            Registro.RegistrarLog(NivelLog.Error,
                                  excepcion.Identificador,
                                  ex);

            throw new WebFaultException<Excepcion>(excepcion, HttpStatusCode.InternalServerError);  
        }
    }
    public void ActualizarConceptoSolicitud(ConceptoSolicitud Sol)
    {
        try
        {
            Registro.RegistrarLog(NivelLog.Debug, "Invocar metodo ActualizarConceptoSolicitud");

            //return new RecursosHumanosBLL().ActualizarConceptoSolicitud(Sol);
            new DatosSolicitudDescansoFisicoBLL().ActualizarConceptoSolicitud(Sol);
        }
        catch (Exception ex)
        {
            Excepcion excepcion = new Excepcion();
            excepcion = ExcepcionWeb.ProcesarExcepcion(ex);

            Registro.RegistrarLog(NivelLog.Error,
                                  excepcion.Identificador,
                                  ex);

            throw new WebFaultException<Excepcion>(excepcion, HttpStatusCode.InternalServerError);  
        }
    }
}