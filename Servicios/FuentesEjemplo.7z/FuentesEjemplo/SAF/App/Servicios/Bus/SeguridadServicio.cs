﻿using SAT.Libreria.Archivos;
using SAT.Libreria.Model;
using SAT.Libreria.Web.Error;
using SAT.Libreria.Web.Servicio;
using SAT.SAF.Model.SE.Seguridad;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace SAT.SAF.App.Servicios.Bus
{
    public class SeguridadServicio
    {
        private const string KSTR_VERIFICAR_USUARIO = "/VerificarUsuario";
        private const string KSTR_LISTAR_MENU_POR_USUARIO = "/ListarMenuUsuario";
        private const string KSTR_LISTAR_OPCION_POR_MENU = "/ListarOpcionMenu";

        public ICacheProvider Cache { get; set; }
        public SeguridadServicio() : this(new CacheProvider())
		{ 

        }
        public SeguridadServicio(ICacheProvider cacheProvider)
        {
            this.Cache = cacheProvider;            
        }
        public UsuarioSAF VerificarUsuario(FiltroUsuario usuario)
        {
            UsuarioSAF lst = new UsuarioSAF();

            try
            {

                string rutaServicioRest = ConfigurationManager.AppSettings["ServicioSeguridadRest"] + KSTR_VERIFICAR_USUARIO;
                string tipoMetodoServicio = Html.KSTR_SERVICIO_POST;

                lst = RESTful.ConectarServicioEntidad<UsuarioSAF, FiltroUsuario>(usuario, rutaServicioRest, tipoMetodoServicio);

                return lst;
            }
            catch (WebException e)
            {
                Excepcion excepcion = new Excepcion();
                excepcion = ExcepcionWeb.ProcesarExcepcion(e);

                throw new Exception(excepcion.Identificador + ": " + excepcion.Description);
            }
            catch
            {
                throw;
            }           
        }

        public List<Menu> ListarMenuPorUsuario(FiltroUsuario usuario)
        {
            List<Menu> lst = new List<Menu>();

            try
            {
                string rutaServicioRest = ConfigurationManager.AppSettings["ServicioRest"] + KSTR_LISTAR_MENU_POR_USUARIO;
                string tipoMetodoServicio = Html.KSTR_SERVICIO_POST;

                lst = RESTful.ConectarServicioLista<Menu, FiltroUsuario>(usuario, rutaServicioRest, tipoMetodoServicio);

                return lst;
            }
            catch (WebException e)
            {
                Excepcion excepcion = new Excepcion();
                excepcion = ExcepcionWeb.ProcesarExcepcion(e);

                throw new Exception(excepcion.Identificador + ": " + excepcion.Description);
            }
            catch
            {
                throw;
            }   
        }

        public List<Control> ListarOpcionMenu(FiltroUsuario usuario) {
            List<Control> lst = new List<Control>();

            try
            {
                string rutaServicioRest = ConfigurationManager.AppSettings["ServicioRest"] + KSTR_LISTAR_OPCION_POR_MENU;
                string tipoMetodoServicio = Html.KSTR_SERVICIO_POST;

                lst = RESTful.ConectarServicioLista<Control, FiltroUsuario>(usuario, rutaServicioRest, tipoMetodoServicio);

                return lst;
            }
            catch (WebException e)
            {
                Excepcion excepcion = new Excepcion();
                excepcion = ExcepcionWeb.ProcesarExcepcion(e);

                throw new Exception(excepcion.Identificador + ": " + excepcion.Description);
            }
            catch
            {
                throw;
            }   
        }
    }
}
