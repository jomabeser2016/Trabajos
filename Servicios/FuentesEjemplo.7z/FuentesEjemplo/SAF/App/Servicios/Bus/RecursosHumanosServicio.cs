﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;

using SAT.Libreria;
using SAT.Libreria.Model;
using SAT.Libreria.Archivos;
using SAT.Libreria.Web.Servicio;
using SAT.Libreria.Web.Error;

using SAT.SAF.Model.GA.RecursosHumanos.DatosSolicitudDescansoFisico;
using SAT.SAF.Model.GA.RecursosHumanos.SolicitudDescansoFisico;
using SAT.SAF.Model.GA.RecursosHumanos.Consultas;
using SAT.SAF.Model.SE.Seguridad;

namespace SAT.SAF.App.Servicios.Bus
{
    public class RecursosHumanosServicio
    {
        private const string KSTR_DEVOLVER_DATOS_TRABAJADOR = "/DevolverDatosTrabajador";
        private const string KSTR_DEVOLVER_SOLICITUD_DESCANSO_FISICO = "/DevolverSolicitudDescansoFisico";
        private const string KSTR_REGISTRAR_DESCANSO_FISICO = "/RegistrarDescansoFisico";
        private const string KSTR_DEVOLVER_DETALLE_SOLICITUD_DESCANSO_FISICO = "/DevolverDetalleSolicitudDescansoFisico";
        private const string KSTR_REGISTRAR_DETALLE_DESCANSO_FISICO = "/RegistrarDetalleDescansoFisico";
        private const string KSTR_DEVOLVER_DATOS_FILTRO_PLANILLA = "/DevolverDatosFiltroPlanilla";
        private const string KSTR_DEVOLVER_DATOS_FILTRO_CARGO = "/DevolverDatosFiltroCargo";
        private const string KSTR_DEVOLVER_DATOS_FILTRO_DEPENDENCIA = "/DevolverDatosFiltroDependencia";
        private const string KSTR_DEVOLVER_DATOS_FILTRO_ESTADO_SOLICITUD = "/DevolverDatosFiltroEstadoSolicitud";
        private const string KSTR_DEVOLVER_DATOS_FILTRO_PERIODO_GENERACION = "/DevolverDatosFiltroPeriodoGeneracion";
        private const string KSTR_DEVOLVER_DATOS_FILTRO_PERIODO_SOLICITUD = "/DevolverDatosFiltroPeriodoSolicitud";
        private const string KSTR_DEVOLVER_DATOS_FILTRO_TRABAJADOR = "/DevolverDatosFiltroTrabajador";
        private const string KSTR_ACTUALIZAR_DETALLE_DESCANSO_FISICO = "/ActualizarDetalleDescansoFisico";
        private const string KSTR_VALIDAR_FECHAS_SOLICITUD_DESCANSO_FISICO = "/ValidarFechasSolicitudDescansoFisico";
        private const string KSTR_DEVOLVER_HISTORIAL_DETALLE_SOLICITUD_DESCANDO_FISICO = "/DevolverHistDetalleSolicitudDescansoFisico";
        private const string KSTR_DEVOLVER_DATOS_SOLICITUD_CONCEPTO = "/DevolverDatosConceptoSolicitud";
        private const string KSTR_REGISTRAR_SOLICITUD_CONCEPTO = "/RegistrarConceptoSolicitud";
        private const string KSTR_ACTUALIZAR_SOLICITUD_CONCEPTO = "/ActualizarConceptoSolicitud";
        private const string KSTR_DEVOLVER_DATOS_TRABAJADOR_LOGIN = "/DevolverDatosTrabajadorLogin";
        public ICacheProvider Cache { get; set; }
        public RecursosHumanosServicio() : this(new CacheProvider())
		{ 

        }
        public RecursosHumanosServicio(ICacheProvider cacheProvider)
        {
            this.Cache = cacheProvider;            
        }

        public List<DatosTrabajador> DevolverDatosTrabajador(DatosTrabajador objDatosTrabajador)
        {         

            List<DatosTrabajador> lst = new List<DatosTrabajador>();

            try
            {
                string rutaServicioRest = ConfigurationManager.AppSettings["ServicioRest"] + KSTR_DEVOLVER_DATOS_TRABAJADOR;
                string tipoMetodoServicio = Html.KSTR_SERVICIO_POST;

                lst = RESTful.ConectarServicioLista<DatosTrabajador, DatosTrabajador>(objDatosTrabajador, rutaServicioRest, tipoMetodoServicio);

                return lst; 
            }
            catch (WebException e) {
                Excepcion excepcion = new Excepcion();
                excepcion = ExcepcionWeb.ProcesarExcepcion(e);                

                throw new Exception(excepcion.Identificador + ": " + excepcion.Description);
            }
            catch {                
                throw;
            }
                       
        }        

        public List<SolicitudDescansoFisico> DevolverSolicitudDescansoFisico(FiltroSolicitud objFiltroSolicitud)
        {
            var listaDescansoFisico = new List<SolicitudDescansoFisico>();
            var filtroDescando = new FiltroSolicitud();            

            try
            {
                string rutaServicioRestRegDesFis = ConfigurationManager.AppSettings["ServicioRest"] + KSTR_REGISTRAR_DESCANSO_FISICO;
                string rutaServicioRest = ConfigurationManager.AppSettings["ServicioRest"] + KSTR_DEVOLVER_SOLICITUD_DESCANSO_FISICO;
                string tipoMetodoServicio = Html.KSTR_SERVICIO_POST;

                listaDescansoFisico = Cache.Get("listaDescansoFisico") as List<SolicitudDescansoFisico>;
                filtroDescando = Cache.Get("filtroDescando") as FiltroSolicitud;

                if (filtroDescando == null)
                {                                        
                    //RESTful.ConectarServicio<FiltroSolicitud>(objFiltroSolicitud, rutaServicioRestRegDesFis, tipoMetodoServicio);

                    if (listaDescansoFisico == null)
                    {                                                 
                        listaDescansoFisico = RESTful.ConectarServicioLista<SolicitudDescansoFisico, FiltroSolicitud>(objFiltroSolicitud, rutaServicioRest, tipoMetodoServicio);

                        if (listaDescansoFisico != null)
                        {
                            Cache.Set("listaDescansoFisico", listaDescansoFisico, 15);
                            Cache.Set("filtroDescando", objFiltroSolicitud, 15);
                        }

                    }
                }
                else 
                {
                    if (filtroDescando.TIPO_PLAN_TPL != objFiltroSolicitud.TIPO_PLAN_TPL || filtroDescando.CODI_EMPL_PER != objFiltroSolicitud.CODI_EMPL_PER)
                    {                                                
                        //RESTful.ConectarServicio<FiltroSolicitud>(objFiltroSolicitud, rutaServicioRestRegDesFis, tipoMetodoServicio);
                        
                        listaDescansoFisico = RESTful.ConectarServicioLista<SolicitudDescansoFisico, FiltroSolicitud>(objFiltroSolicitud, rutaServicioRest, tipoMetodoServicio);

                        if (listaDescansoFisico != null)
                        {
                            Cache.Set("listaDescansoFisico", listaDescansoFisico, 15);
                            Cache.Set("filtroDescando", objFiltroSolicitud, 15);
                        }
                        
                    }
                }

                return listaDescansoFisico;

            }
            catch (WebException e)
            {
                Excepcion excepcion = new Excepcion();
                excepcion = ExcepcionWeb.ProcesarExcepcion(e);

                throw new Exception(excepcion.Identificador + ": " + excepcion.Description);
            }
            catch
            {                
                throw;
            }
            
        }        

        public List<SolicitudDescansoFisico> ObtenerDiasporAnio(FiltroSolicitud objFiltroSolicitud)
        {
            var listaDescansoFisico = new List<SolicitudDescansoFisico>();

            try
            {
                string rutaServicioRestRegDesFis = ConfigurationManager.AppSettings["ServicioRest"] + KSTR_REGISTRAR_DESCANSO_FISICO;
                string rutaServicioRest = ConfigurationManager.AppSettings["ServicioRest"] + KSTR_DEVOLVER_SOLICITUD_DESCANSO_FISICO;
                string tipoMetodoServicio = Html.KSTR_SERVICIO_POST;

                listaDescansoFisico = RESTful.ConectarServicioLista<SolicitudDescansoFisico, FiltroSolicitud>(objFiltroSolicitud, rutaServicioRest, tipoMetodoServicio);
                listaDescansoFisico = listaDescansoFisico.Where(x => x.ANIO_GENE_DFI == objFiltroSolicitud.PERI_GENE_DFI).ToList();  

                return listaDescansoFisico;
            }
            catch (WebException e)
            {
                Excepcion excepcion = new Excepcion();
                excepcion = ExcepcionWeb.ProcesarExcepcion(e);

                throw new Exception(excepcion.Identificador + ": " + excepcion.Description);
            }
            catch
            {                
                throw;
            }
            
        }

        public JQGrid DevolverDetalleSolicitudDescansoFisico(FiltroSolicitud objFiltroSolicitud)
        {
            JQGrid objJQGrid = new JQGrid();
            List<ListaDetalleSolicitudDescansoFisico> lst = new List<ListaDetalleSolicitudDescansoFisico>();
            try
            {
                
                string rutaServicioRest = ConfigurationManager.AppSettings["ServicioRest"] + KSTR_DEVOLVER_DETALLE_SOLICITUD_DESCANSO_FISICO;
                string tipoMetodoServicio = Html.KSTR_SERVICIO_POST;

                List<string> lstCampos = new List<string>();
                lstCampos.Add("CODI_EMPL_PER");
                lstCampos.Add("NOMB_EMPL_PER");
                lstCampos.Add("DESC_PLAN_TPL");
                lstCampos.Add("TIPO_PLAN_TPL");
                lstCampos.Add("NOMB_PUES_TNI");
                lstCampos.Add("NOMB_EST_DDF");
                lstCampos.Add("CODI_EST_DDF");
                lstCampos.Add("INIC_PROG_DDF");
                lstCampos.Add("FINA_PROG_DDF");
                lstCampos.Add("ANIO_GENE_DFI");
                lstCampos.Add("PERI_GENE_DDF");
                lstCampos.Add("DIAS_PROG_DDF");
                lstCampos.Add("OBSE_REGI_DDF");
                lstCampos.Add("OBSE_ACTU_DDF");
                lstCampos.Add("CADE_SOLI_DFI");
                lstCampos.Add("SECU_PROG_DDF");
                lstCampos.Add("FECH_REGI_DDF");
                
                lst = RESTful.ConectarServicioLista<ListaDetalleSolicitudDescansoFisico, FiltroSolicitud>(objFiltroSolicitud, rutaServicioRest, tipoMetodoServicio);
                objJQGrid = SAT.Libreria.JavaScript.JQuery.ListJQGrid<ListaDetalleSolicitudDescansoFisico>(lst, lstCampos, TipoAdministracionPaginacion.PorClase);
                objJQGrid.page = 1;
                return objJQGrid;
            }
            catch (WebException e)
            {
                Excepcion excepcion = new Excepcion();
                excepcion = ExcepcionWeb.ProcesarExcepcion(e);

                throw new Exception(excepcion.Identificador + ": " + excepcion.Description);
            }
            catch
            {
                throw;
            }
            
        }        

        public void RegistrarDetalleDescansoFisico(List<DetalleSolicitudDescansoFisico> objDetalleSolicitudDescansoFisico)
        {
            try
            {
                string rutaServicioRest = ConfigurationManager.AppSettings["ServicioRest"] + KSTR_REGISTRAR_DETALLE_DESCANSO_FISICO;
                string tipoMetodoServicio = Html.KSTR_SERVICIO_POST;

                RESTful.ConectarServicio<DetalleSolicitudDescansoFisico>(objDetalleSolicitudDescansoFisico, rutaServicioRest, tipoMetodoServicio);                
            }
            catch (WebException e)
            {
                Excepcion excepcion = new Excepcion();
                excepcion = ExcepcionWeb.ProcesarExcepcion(e);

                throw new Exception(excepcion.Identificador + ": " + excepcion.Description);
            }
            catch
            {
                throw;
            }            
        }

        public void ActualizarDetalleDescansoFisico(List<DetalleSolicitudDescansoFisico> objDetalleSolicitudDescansoFisico)
        {
            try
            {
                string rutaServicioRest = ConfigurationManager.AppSettings["ServicioRest"] + KSTR_ACTUALIZAR_DETALLE_DESCANSO_FISICO;
                string tipoMetodoServicio = Html.KSTR_SERVICIO_POST;
                
                RESTful.ConectarServicio<DetalleSolicitudDescansoFisico>(objDetalleSolicitudDescansoFisico, rutaServicioRest, tipoMetodoServicio);
            }
            catch (WebException e)
            {
                Excepcion excepcion = new Excepcion();
                excepcion = ExcepcionWeb.ProcesarExcepcion(e);

                throw new Exception(excepcion.Identificador + ": " + excepcion.Description);
            }
            catch
            {
                throw;
            }
        } 

        public List<ItemSelectList> DevolverDatosFiltroPlanilla()
        {
            List<ItemSelectList> lst = new List<ItemSelectList>();

            try
            {
                string rutaServicioRest = ConfigurationManager.AppSettings["ServicioRest"] + KSTR_DEVOLVER_DATOS_FILTRO_PLANILLA;
                string tipoMetodoServicio = Html.KSTR_SERVICIO_POST;

                lst = RESTful.ConeccionServicioLista<ItemSelectList>(rutaServicioRest, tipoMetodoServicio);

                return lst;
            }
            catch (WebException e)
            {
                Excepcion excepcion = new Excepcion();
                excepcion = ExcepcionWeb.ProcesarExcepcion(e);

                throw new Exception(excepcion.Identificador + ": " + excepcion.Description);
            }
            catch
            {
                throw;
            }            
        }        

        public List<ItemSelectList> DevolverDatosFiltroCargo()
        {
            List<ItemSelectList> lst = new List<ItemSelectList>();

            try
            {
                string rutaServicioRest = ConfigurationManager.AppSettings["ServicioRest"] + KSTR_DEVOLVER_DATOS_FILTRO_CARGO;
                string tipoMetodoServicio = Html.KSTR_SERVICIO_POST;

                lst = RESTful.ConeccionServicioLista<ItemSelectList>(rutaServicioRest, tipoMetodoServicio);

                return lst;
            }
            catch (WebException e) {
                Excepcion excepcion = new Excepcion();
                excepcion = ExcepcionWeb.ProcesarExcepcion(e);                

                throw new Exception(excepcion.Identificador + ": " + excepcion.Description);
            }
            catch {                
                throw;
            }
            
        }        

        public List<ItemSelectList> DevolverDatosFiltroDependencia()
        {
            List<ItemSelectList> lst = new List<ItemSelectList>();

            try
            {
                string rutaServicioRest = ConfigurationManager.AppSettings["ServicioRest"] + KSTR_DEVOLVER_DATOS_FILTRO_DEPENDENCIA;
                string tipoMetodoServicio = Html.KSTR_SERVICIO_POST;

                lst = RESTful.ConeccionServicioLista<ItemSelectList>(rutaServicioRest, tipoMetodoServicio);

                return lst;
            }
            catch (WebException e)
            {
                Excepcion excepcion = new Excepcion();
                excepcion = ExcepcionWeb.ProcesarExcepcion(e);

                throw new Exception(excepcion.Identificador + ": " + excepcion.Description);
            }
            catch
            {
                throw;
            }
        }        

        public List<ItemSelectList> DevolverDatosFiltroEstadoSolicitud()
        {
            List<ItemSelectList> lst = new List<ItemSelectList>();
            
            try {
                string rutaServicioRest = ConfigurationManager.AppSettings["ServicioRest"] + KSTR_DEVOLVER_DATOS_FILTRO_ESTADO_SOLICITUD;
                string tipoMetodoServicio = Html.KSTR_SERVICIO_POST;

                lst = RESTful.ConeccionServicioLista<ItemSelectList>(rutaServicioRest, tipoMetodoServicio);

                return lst;                
            }
            catch (WebException e)
            {
                Excepcion excepcion = new Excepcion();
                excepcion = ExcepcionWeb.ProcesarExcepcion(e);

                throw new Exception(excepcion.Identificador + ": " + excepcion.Description);
            }
            catch
            {
                throw;
            }            
        }        

        public List<ItemSelectList> DevolverDatosFiltroPeriodoGeneracion(FiltroSolicitud objFiltroSolicitud)
        {
            List<ItemSelectList> lst = new List<ItemSelectList>();

            try {

                string rutaServicioRest = ConfigurationManager.AppSettings["ServicioRest"] + KSTR_DEVOLVER_DATOS_FILTRO_PERIODO_GENERACION;
                string tipoMetodoServicio = Html.KSTR_SERVICIO_POST;

                lst = RESTful.ConectarServicioLista<ItemSelectList, FiltroSolicitud>(objFiltroSolicitud, rutaServicioRest, tipoMetodoServicio);

                return lst;                
            }
            catch (WebException e)
            {
                Excepcion excepcion = new Excepcion();
                excepcion = ExcepcionWeb.ProcesarExcepcion(e);

                throw new Exception(excepcion.Identificador + ": " + excepcion.Description);
            }
            catch
            {
                throw;
            }   

        }

        public List<ItemSelectList> DevolverDatosFiltroPeriodoSolicitud(FiltroSolicitud objFiltroSolicitud)
        {
            List<ItemSelectList> lst = new List<ItemSelectList>();

            try{
                string rutaServicioRest = ConfigurationManager.AppSettings["ServicioRest"] + KSTR_DEVOLVER_DATOS_FILTRO_PERIODO_SOLICITUD;
                string tipoMetodoServicio = Html.KSTR_SERVICIO_POST;

                lst = RESTful.ConectarServicioLista<ItemSelectList, FiltroSolicitud>(objFiltroSolicitud, rutaServicioRest, tipoMetodoServicio);

                return lst;                
            }
            catch (WebException e)
            {
                Excepcion excepcion = new Excepcion();
                excepcion = ExcepcionWeb.ProcesarExcepcion(e);

                throw new Exception(excepcion.Identificador + ": " + excepcion.Description);
            }
            catch
            {
                throw;
            }
            
        }

        public List<ItemSelectList> DevolverDatosFiltroTrabajador(FiltroSolicitud objFiltroSolicitud)
        {
            List<ItemSelectList> listaTrabajador = new List<ItemSelectList>();            

            try {
                string rutaServicioRest = ConfigurationManager.AppSettings["ServicioRest"] + KSTR_DEVOLVER_DATOS_FILTRO_TRABAJADOR;
                string tipoMetodoServicio = Html.KSTR_SERVICIO_POST;

                listaTrabajador = RESTful.ConectarServicioLista<ItemSelectList, FiltroSolicitud>(objFiltroSolicitud, rutaServicioRest, tipoMetodoServicio);

                return listaTrabajador;                
            }
            catch (WebException e)
            {
                Excepcion excepcion = new Excepcion();
                excepcion = ExcepcionWeb.ProcesarExcepcion(e);

                throw new Exception(excepcion.Identificador + ": " + excepcion.Description);
            }
            catch
            {
                throw;
            }            
        }

        public List<ValidaFecha> ValidarFechasSolicitudDescansoFisico(ValidaFecha objValidaFecha)
        {
            List<ValidaFecha> lst = new List<ValidaFecha>();

            try
            {
                string rutaServicioRest = ConfigurationManager.AppSettings["ServicioRest"] + KSTR_VALIDAR_FECHAS_SOLICITUD_DESCANSO_FISICO;
                string tipoMetodoServicio = Html.KSTR_SERVICIO_POST;

                lst = RESTful.ConectarServicioLista<ValidaFecha, ValidaFecha>(objValidaFecha, rutaServicioRest, tipoMetodoServicio);

                return lst;
            }
            catch (WebException e)
            {
                Excepcion excepcion = new Excepcion();
                excepcion = ExcepcionWeb.ProcesarExcepcion(e);

                throw new Exception(excepcion.Identificador + ": " + excepcion.Description);
            }
            catch
            {
                throw;
            }
        }
 
        public JQGrid DevolverHistDetalleSolicitudDescansoFisico(FiltroSolicitud objFiltroSolicitud)
        {
            JQGrid objJQGrid = new JQGrid();
            List<ListaHistorialSolicitudDescansoFisico> lst = new List<ListaHistorialSolicitudDescansoFisico>();

            try
            {
                string rutaServicioRest = ConfigurationManager.AppSettings["ServicioRest"] + KSTR_DEVOLVER_HISTORIAL_DETALLE_SOLICITUD_DESCANDO_FISICO;
                string tipoMetodoServicio = Html.KSTR_SERVICIO_POST;
                List<string> lstCampos = new List<string>();

                lst = RESTful.ConectarServicioLista<ListaHistorialSolicitudDescansoFisico, FiltroSolicitud>(objFiltroSolicitud, rutaServicioRest, tipoMetodoServicio);
                lstCampos.Add("TIPO_PLAN_TPL");
                lstCampos.Add("CODI_EMPL_PER");
                lstCampos.Add("NOMB_EMPL_PER");
                lstCampos.Add("NOMB_EST_DDF");
                lstCampos.Add("ANIO_GENE_DFI");
                lstCampos.Add("PERI_GENE_DDF");
                lstCampos.Add("SECU_PROG_DDF");
                lstCampos.Add("INIC_PROG_DDF");
                lstCampos.Add("FINA_PROG_DDF");
                lstCampos.Add("DIAS_PROG_DDF");
                lstCampos.Add("FECH_REGI_DDF");
                lstCampos.Add("USER_REGI_DDF");
                lstCampos.Add("OBSE_REGI_DDF");
                lstCampos.Add("FECH_ACTU_DDF");
                lstCampos.Add("USER_ACTU_DDF");
                lstCampos.Add("OBSE_ACTU_DDF");

                objJQGrid = SAT.Libreria.JavaScript.JQuery.ListJQGrid<ListaHistorialSolicitudDescansoFisico>(lst, lstCampos, TipoAdministracionPaginacion.PorClase);
                return objJQGrid;
            }
            catch (WebException e)
            {
                Excepcion excepcion = new Excepcion();
                excepcion = ExcepcionWeb.ProcesarExcepcion(e);

                throw new Exception(excepcion.Identificador + ": " + excepcion.Description);
            }
            catch
            {
                throw;
            }
        }

        public JQGrid DevolverDatosSolicitudConcepto()
        {
            JQGrid objJQGrid = new JQGrid();
            List<ListaConceptoSolicitud> lst = new List<ListaConceptoSolicitud>();

            try
            {
                string rutaServicioRest = ConfigurationManager.AppSettings["ServicioRest"] + KSTR_DEVOLVER_DATOS_SOLICITUD_CONCEPTO;
                string tipoMetodoServicio = Html.KSTR_SERVICIO_POST;
                List<string> lstCampos = new List<string>();
                lst = RESTful.ConeccionServicioLista<ListaConceptoSolicitud>(rutaServicioRest, tipoMetodoServicio);
                lstCampos.Add("TIPO_PARAM_DFI");
                lstCampos.Add("CADE_PARAM_DFI");
                lstCampos.Add("CODI_PARAM_DFI");
                lstCampos.Add("NOM_PARAM_DFI");
                lstCampos.Add("ESTA_PARAM_DFI");
                lstCampos.Add("QRY_PARAM_DFI");
                lstCampos.Add("MSJ_PARAM_DFI");
                lstCampos.Add("LOGI_REG_PARAM_DFI");
                lstCampos.Add("FECH_REG_PARAM_DFI");
                lstCampos.Add("LOGI_ACT_PARAM_DFI");
                lstCampos.Add("FECH_ACT_PARAM_DFI");                
                objJQGrid = SAT.Libreria.JavaScript.JQuery.ListJQGrid<ListaConceptoSolicitud>(lst, lstCampos, TipoAdministracionPaginacion.PorClase);
                return objJQGrid;
            }
            catch (WebException e)
            {
                Excepcion excepcion = new Excepcion();
                excepcion = ExcepcionWeb.ProcesarExcepcion(e);

                throw new Exception(excepcion.Identificador + ": " + excepcion.Description);
            }
            catch
            {
                throw;
            }
        }

        public void RegistrarConceptoSolicitud(ConceptoSolicitud objConceptoSolicitud)
        {
            
            try
            {
                string rutaServicioRest = ConfigurationManager.AppSettings["ServicioRest"] + KSTR_REGISTRAR_SOLICITUD_CONCEPTO;
                string tipoMetodoServicio = Html.KSTR_SERVICIO_POST;

                RESTful.ConectarServicio<ConceptoSolicitud>(objConceptoSolicitud, rutaServicioRest, tipoMetodoServicio);
            }
            catch (WebException e)
            {
                Excepcion excepcion = new Excepcion();
                excepcion = ExcepcionWeb.ProcesarExcepcion(e);

                throw new Exception(excepcion.Identificador + ": " + excepcion.Description);
            }
            catch
            {
                throw;
            }
        }

        public void ActualizarConceptoSolicitud(ConceptoSolicitud objConceptoSolicitud)
        {

            try
            {
                string rutaServicioRest = ConfigurationManager.AppSettings["ServicioRest"] + KSTR_ACTUALIZAR_SOLICITUD_CONCEPTO;
                string tipoMetodoServicio = Html.KSTR_SERVICIO_POST;

                RESTful.ConectarServicio<ConceptoSolicitud>(objConceptoSolicitud, rutaServicioRest, tipoMetodoServicio);
            }
            catch (WebException e)
            {
                Excepcion excepcion = new Excepcion();
                excepcion = ExcepcionWeb.ProcesarExcepcion(e);

                throw new Exception(excepcion.Identificador + ": " + excepcion.Description);
            }
            catch
            {
                throw;
            }
        }

        public List<DatosTrabajadorLogin> DevolverDatosTrabajadorLogin(FiltroUsuario objFiltroUsuario)
        {
            List<DatosTrabajadorLogin> lst = new List<DatosTrabajadorLogin>();
            try
            {
                string rutaServicioRest = ConfigurationManager.AppSettings["ServicioRest"] + KSTR_DEVOLVER_DATOS_TRABAJADOR_LOGIN;
                string tipoMetodoServicio = Html.KSTR_SERVICIO_POST;
                lst = RESTful.ConectarServicioLista<DatosTrabajadorLogin, FiltroUsuario>(objFiltroUsuario, rutaServicioRest, tipoMetodoServicio);

                return lst;
            }
            catch (WebException e)
            {
                Excepcion excepcion = new Excepcion();
                excepcion = ExcepcionWeb.ProcesarExcepcion(e);

                throw new Exception(excepcion.Identificador + ": " + excepcion.Description);
            }
        }
    }
}