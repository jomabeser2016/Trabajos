﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.Optimization;

using Forloop.HtmlHelpers;

using RecursosHumanos.App_Start;
using System.Web.Security;
using System.Configuration;
using SAT.Libreria.Seguridad.Encriptacion;
using System.Text;

namespace RecursosHumanos
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            //Habilitar el ForloopHelper para utilizar scripts JS en los partialview
            ScriptContext.ScriptPathResolver = Scripts.Render;
        }

        protected void Application_AuthenticateRequest(Object sender, EventArgs e)
        {
            //var cookieName = FormsAuthentication.FormsCookieName;
            //var authCookie = Context.Request.Cookies[cookieName];
            //if (null == authCookie)
            //{
            //    //Response.Redirect("http://localhost:8568/Account/Login.aspx?ReturnUrl=" + Request.Url.AbsoluteUri);

            //    var urlLogin = ConfigurationManager.AppSettings.Get("UrlLogin");
            //    var sistema = ConfigurationManager.AppSettings.Get("Sistema");
            //    var ruta = urlLogin + "?sistema=" + sistema + "&retorno=" + Request.Url.AbsoluteUri;

            //    Response.Redirect(ruta);
            //}
            var cookieName = FormsAuthentication.FormsCookieName;
            var authCookie = Context.Request.Cookies[cookieName];

            //FormsIdentity formIdentity = System.Web.HttpContext.Current.User.Identity as FormsIdentity;
            //string usuario = formIdentity.Name.ToString();

            //Registro.RegistrarLog(NivelLog.Debug, "authCookie: " + authCookie);
            //Registro.RegistrarLog(NivelLog.Debug, "Usuario: " + usuario.ToString());            

            if (null == authCookie)
            {
                //Response.Redirect("http://localhost:8568/Account/Login.aspx?ReturnUrl=" + Request.Url.AbsoluteUri);

                var urlLogin = ConfigurationManager.AppSettings.Get("UrlLogin");
                var llave = AES.ObtenerKey(ConfigurationManager.AppSettings.Get("AplicativoLogin"));

                byte[] keyByte = UTF8Encoding.UTF8.GetBytes(llave);
                var sistema = HttpContext.Current.Server.UrlEncode(AES.Encriptar(ConfigurationManager.AppSettings.Get("Sistema"), keyByte));
                var sistemaCodigo = HttpContext.Current.Server.UrlEncode(AES.Encriptar(ConfigurationManager.AppSettings.Get("SistemaCodigo"), keyByte));
                var moduloCodigo = HttpContext.Current.Server.UrlEncode(AES.Encriptar(ConfigurationManager.AppSettings.Get("ModuloCodigo"), keyByte));

                var urlSistema = HttpContext.Current.Server.UrlEncode(AES.Encriptar(Request.Url.AbsoluteUri.ToString(), keyByte));

                //var sistema = AES.Encriptar(ConfigurationManager.AppSettings.Get("Sistema"), keyByte);
                //var urlSistema = AES.Encriptar(Request.Url.AbsoluteUri.ToString(), keyByte);

                //var ruta = urlLogin + "?sistema=" + sistema + "&retorno=" + Request.Url.AbsoluteUri;
                var ruta = urlLogin + "?sistema=" + sistema + "&sistemaCodigo=" + sistemaCodigo + "&moduloCodigo=" + moduloCodigo + "&retorno=" + urlSistema;

                Response.Redirect(ruta);
            }
        }
    }
}
