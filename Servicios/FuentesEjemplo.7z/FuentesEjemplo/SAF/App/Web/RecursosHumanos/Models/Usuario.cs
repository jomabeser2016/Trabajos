﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RecursosHumanos.Models
{
    public class Usuario : SAT.Libreria.App.Usuario
    {
    }
}