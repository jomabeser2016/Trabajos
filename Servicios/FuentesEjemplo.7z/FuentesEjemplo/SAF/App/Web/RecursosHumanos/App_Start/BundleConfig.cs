﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;

namespace RecursosHumanos.App_Start
{
    public class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            /*****************SECCIÓN DE SCRIPTS****************/
            bundles.Add(new ScriptBundle("~/bootstrap/css").Include(
                "~/bootstrap/css/bootstrap.min.css")
            );

            bundles.Add(new ScriptBundle("~/plugins/css").Include(
                "~/plugins/font-awesome-4.6.1/css/font-awesome.min.css",
                "~/plugins/ionicons-master/css/ionicons.min.css",
                "~/plugins/iCheck/all.css",
                "~/plugins/select2/select2.min.css",
                "~/plugins/JQGrid/theme/smoothness/jquery-ui.min.css",
                "~/plugins/JQGrid/css/ui.jqgrid.min.css",
                "~/plugins/datepicker/datepicker3.css")
            );

            bundles.Add(new ScriptBundle("~/dist/css").Include(
                "~/dist/css/AdminLTE.min.css",
                "~/dist/css/skins/skin-SAT.css",
                "~/dist/css/General.css")
            );

            /*****************SECCIÓN DE JS**********************/
            bundles.Add(new ScriptBundle("~/plugins/jQuery").Include(
                "~/plugins/jQuery/jquery-2.2.3.min.js")
            );

            bundles.Add(new ScriptBundle("~/plugins/validation").Include(
                "~/plugins/validation/jquery.validate.min.js",
                "~/plugins/validation/jquery.validate.unobtrusive.min.js")                
            );

            bundles.Add(new ScriptBundle("~/bootstrap/js").Include(
                "~/bootstrap/js/bootstrap.min.js")
            );

            bundles.Add(new ScriptBundle("~/plugins/js").Include(
                "~/plugins/select2/select2.full.min.js",
                "~/plugins/input-mask/jquery.inputmask.js",
                "~/plugins/input-mask/jquery.inputmask.date.extensions.js",
                "~/plugins/input-mask/jquery.inputmask.extensions.js", 
                "~/plugins/datatables/jquery.dataTables.min.js",
                "~/plugins/datatables/dataTables.bootstrap.min.js",
                "~/plugins/iCheck/icheck.min.js",
                "~/plugins/fastclick/fastclick.min.js",
                "~/plugins/slimScroll/jquery.slimscroll.min.js",
                "~/plugins/JQGrid/i18n/grid.locale-es.min.js",
                "~/plugins/JQGrid/jquery.jqgrid.min.js",
                "~/plugins/datepicker/bootstrap-datepicker.js",
                "~/plugins/datepicker/locales/bootstrap-datepicker.es.js")
            );

            bundles.Add(new ScriptBundle("~/dist/js").Include(
                "~/dist/js/app.min.js")
            );

            bundles.Add(new ScriptBundle("~/Scripts/Layout").Include(
                "~/Scripts/utils/Timer.js",
                "~/Scripts/utils/FuncionJS.js",
                "~/Scripts/utils/CustomValidation.js",
                "~/Scripts/Layout.js")
            );

            /*ACTIVAR EN PRODUCCION PARA LA OPCION DE MINIFICACION
            Adicionalmente en el Web.config se deberá modificar la siguiente línea
            <compilation debug="true" />
            */
            //BundleTable.EnableOptimizations = true; 
        }
    }
}