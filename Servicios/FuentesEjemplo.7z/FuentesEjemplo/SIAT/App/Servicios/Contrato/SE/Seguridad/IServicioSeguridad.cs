﻿using System.ServiceModel;
using System.ServiceModel.Web;

using SAT.SIAT.Model.SE.Seguridad;

namespace SAT.SIAT.App.Servicios.Contrato.SE.Seguridad
{
    ///<summary>Clase que representa el contrato del Servicio para El MININTER</summary>
    ///<remarks>
    ///<list type = "bullet">
    ///<item><CreadoPor>Edgard M. Márquez A.</CreadoPor></item>
    ///<item><FecCrea>11/03/2016</FecCrea></item>
    ///</list></remarks>
    [ServiceContract]
    public interface IServicioSeguridad
    {
        /// <summary>Método que Comprueba la existencia de un usuario.</summary>
        [OperationContract(Name = "ComprobarAcceso")]
        [WebInvoke(Method = "POST",
                   ResponseFormat = WebMessageFormat.Json,
                   RequestFormat = WebMessageFormat.Json,
                   BodyStyle = WebMessageBodyStyle.Bare,
                   UriTemplate = "ComprobarAcceso")]
        bool ComprobarAcceso(SGMaeUsu usuario);
    }
}
