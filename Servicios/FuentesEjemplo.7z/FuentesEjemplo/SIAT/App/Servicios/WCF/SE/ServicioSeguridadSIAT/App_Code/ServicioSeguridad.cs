﻿using System;
using System.Net;
using System.ServiceModel;
using System.ServiceModel.Web;

using SAT.Libreria.Log;
using SAT.Libreria.Model;
using SAT.Libreria.Web.Error;

using SAT.SIAT.Model.SE.Seguridad;

// NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "Service1" en el código, en svc y en el archivo de configuración.
public class ServicioSeguridad : SAT.SIAT.App.Servicios.Contrato.SE.Seguridad.IServicioSeguridad
{
    /// <summary>Método que Comprueba la existencia de un usuario.</summary>
    /// <param name="usuario">Entidad con los datos del usuario.</param>
    /// <returns>Verdadero si el acceso es comprobado.</returns>
    /// <remarks><list type="bullet">
    /// <item><CreadoPor>Edgard M. Márquez A.</CreadoPor></item>
    /// <item><FecCrea>09/05/2016.</FecCrea></item></list>
    /// <list type="bullet">
    /// <item><FecActu>XX/XX/XXXX.</FecActu></item>
    /// <item><Resp>Responsable.</Resp></item>
    /// <item><Mot>Motivo.</Mot></item></list></remarks>
    public bool ComprobarAcceso(SGMaeUsu usuario)
    {
        bool respuesta = false;
        try
        {
            SAT.Libreria.Log.Registro.RegistrarLog(SAT.Libreria.Log.NivelLog.Debug, "ComprobarAcceso - Usuario: " + SAT.Libreria.Objeto.DevolverAtributosDatos(usuario));
            respuesta = new SAT.SIAT.App.Servicios.BLL.SE.Seguridad.SeguridadBLL().ComprobarAcceso(usuario);
            SAT.Libreria.Log.Registro.RegistrarLog(SAT.Libreria.Log.NivelLog.Debug, "ComprobarAcceso - Fin");
        }
        catch (Exception ex)
        {
            Excepcion excepcion = new Excepcion();
            excepcion = ExcepcionWeb.ProcesarExcepcion(ex);

            Registro.RegistrarLog(NivelLog.Error,
                                  excepcion.Identificador,
                                  ex);

            throw new WebFaultException<Excepcion>(excepcion, HttpStatusCode.InternalServerError);   
        }

        return respuesta;
    }
}
