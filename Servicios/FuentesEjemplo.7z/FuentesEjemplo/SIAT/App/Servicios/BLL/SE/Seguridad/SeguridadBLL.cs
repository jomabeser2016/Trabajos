﻿using System;
using SAT.SIAT.Model.SE.Seguridad;
using SAT.SIAT.App.Servicios.DAL.SE.Seguridad;

namespace SAT.SIAT.App.Servicios.BLL.SE.Seguridad
{
    public class SeguridadBLL
    {
        /// <summary>Método que Comprueba la existencia de un usuario.</summary>
        /// <param name="usuario">Entidad con los datos del usuario.</param>
        /// <returns>Verdadero si el acceso es comprobado.</returns>
        /// <remarks><list type="bullet">
        /// <item><CreadoPor>Edgard M. Márquez A.</CreadoPor></item>
        /// <item><FecCrea>09/05/2016.</FecCrea></item></list>
        /// <list type="bullet">
        /// <item><FecActu>XX/XX/XXXX.</FecActu></item>
        /// <item><Resp>Responsable.</Resp></item>
        /// <item><Mot>Motivo.</Mot></item></list></remarks>
        public bool ComprobarAcceso(SGMaeUsu usuario)
        {
            try
            {
                return new SeguridadDAL().ComprobarAcceso(usuario);
            }
            catch
            {
                throw;
            }
        }
    }
}
