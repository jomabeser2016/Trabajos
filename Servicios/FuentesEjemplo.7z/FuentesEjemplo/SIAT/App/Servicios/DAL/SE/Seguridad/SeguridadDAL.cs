﻿using System.Data;
using System.Data.Common;

using SAT.SIAT.Model.SE.Seguridad;
using SAT.Libreria.EnterpriseLibrary.DataAccessApplicationBlock.Sql;


namespace SAT.SIAT.App.Servicios.DAL.SE.Seguridad
{
    ///<summary>Clase que implementa metódos para consultar la Seguridad</summary>
    ///<remarks>
    ///<list type = "bullet">
    ///<item><CreadoPor>Edgard M. Márquez A.</CreadoPor></item>
    ///<item><FecCrea>09/05/2016</FecCrea></item>
    ///</list></remarks>
    public class SeguridadDAL
    {
        #region Constantes
        private const string KSTR_NOMBRE_DB_SEGURIDAD = "Seguridad";
        private const string KSTR_NOMBRE_DB_NOTRIBUTARIO = "NoTributario";
        private const string KSTR_NOMBRE_DB_TRIBUTARIO = "Tributario";
        #endregion

        #region Metodos publicos
        /// <summary>Método que Comprueba la existencia de un usuario.</summary>
        /// <param name="usuario">Entidad con los datos del usuario.</param>
        /// <returns>Verdadero si el acceso es comprobado.</returns>
        /// <remarks><list type="bullet">
        /// <item><CreadoPor>Edgard M. Márquez A.</CreadoPor></item>
        /// <item><FecCrea>09/05/2016.</FecCrea></item></list>
        /// <list type="bullet">
        /// <item><FecActu>XX/XX/XXXX.</FecActu></item>
        /// <item><Resp>Responsable.</Resp></item>
        /// <item><Mot>Motivo.</Mot></item></list></remarks>
        public bool ComprobarAcceso(SGMaeUsu usuario)
        {
            var objDatabase = DatabaseFactory.CrearDatabase(KSTR_NOMBRE_DB_SEGURIDAD, KSTR_NOMBRE_DB_SEGURIDAD);
            DbCommand cmd;
            bool resultado = false;
            try
            {
                using (DbConnection con = objDatabase.CreateConnection())
                {
                    con.Open();
                    try
                    {
                        cmd = objDatabase.GetStoredProcCommand("dbo.spSe_Seguridad_ComprobarAcceso");
                        objDatabase.AddInParameter(cmd, "@pcLogUsu", DbType.String, usuario.cLogUsu);
                        objDatabase.AddInParameter(cmd, "@pcPasUsu", DbType.String, usuario.cPasUsu);
                        using (System.Data.IDataReader dr = objDatabase.ExecuteReader(cmd))
                        {
                            if (dr.Read())
                            {
                                resultado = true;
                            }
                        }
                    }
                    catch
                    {
                        throw;
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            catch
            {
                throw;
            }

            return resultado;
        }
        #endregion
    }
}