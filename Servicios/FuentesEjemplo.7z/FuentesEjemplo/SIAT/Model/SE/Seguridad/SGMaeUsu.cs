﻿using System;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;

namespace SAT.SIAT.Model.SE.Seguridad
{
    [DataContract]
    public class SGMaeUsu
    {
        [DataMember]
        public Int16 siCodUsu { get; set; }

        [DataMember]
        public string cLogUsu { get; set; }

        [DataMember]
        public Int32 iNumReg { get; set; }

        [DataMember]
        public string cNomUsu { get; set; }

        [DataMember]
        public string vApePat { get; set; }

        [DataMember]
        public string vApeMat { get; set; }

        [DataMember]
        public string vNombre { get; set; }

        [DataMember]
        public string cPasUsu { get; set; }

        [DataMember]
        public bool bActivo { get; set; }

        [DataMember]
        public Int16 siCodUsuA { get; set; }

        [DataMember]
        public DateTime sdFecAct { get; set; }

        [DataMember]
        public Int16 siCamPas { get; set; }

        [DataMember]
        public Int16 siTipDId { get; set; }

        [DataMember]
        public string cDocIde { get; set; }

        [DataMember]
        public string cNomTer { get; set; }

        [DataMember]
        public string vObservacion { get; set; }

        [DataMember]
        public DateTime sdFecCamPassword { get; set; }
    }
}
