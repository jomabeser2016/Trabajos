﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SAT.SIAT.Libreria
{
    ///<summary>Clase con datos para la aplicacion.</summary>
    ///<item><CreadoPor>Edgard M. Márquez A.</CreadoPor></item>
    ///<item><FecCrea>09/05/2016</FecCrea></item>
    public sealed class Aplicacion
    {
        private static Int16 codigoMunicipalidad = 1;

        ///<summary>Registra y devuelve el código de la municipalidad.</summary>
        ///<item><CreadoPor>Edgard M. Márquez A.</CreadoPor></item>
        ///<item><FecCrea>09/05/2016</FecCrea></item>
        public static Int16 siCodMun
        {
            get { return codigoMunicipalidad; }
            set { codigoMunicipalidad = value; }
        }
    }
}
