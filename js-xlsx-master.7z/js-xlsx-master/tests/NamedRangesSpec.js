﻿var XLSX = require('../');
var testCommon = require('./Common.js');

var file = 'named_ranges_2011.xlsx';

describe(file, function () {
	testCommon(file);
});