USE [SIAT001]
GO
--********************************************************************************************************************** 
-- Descripcion       : Devuelve Datos de la Naturaleza de Deuda
-- Output            : Datos de Naturaleza de Deuda.
-- Creado por        : Jose Manuel Benites Sernaque
-- RQ                : 137404
-- Motivo            : Proyecto MCSISAT
-- Fecha             : 07/11/2016
-- Replicado         : <Fecha Replicado> - <SERVIDOR>.<BASE DATOS>
----------------------------------------------------------------------------------------------------------------------  
-- Fec Actualizaci�n : XX/XX/XXXX
-- Responsable       : Analista
-- RQ                : <Numero de Requerimiento>
-- Motivo            : <Motivo de la modificacion> 
--**********************************************************************************************************************
Create Procedure [dbo].[spSG_Deuda_ListarNaturaleza]
As
Begin   
	Set NoCount On
		
   Select siCodNDe,
          vDesNDe  
   From SIAT001.dbo.SGTabNDe(NoLock)  
      
	Set NoCount Off
   
End   