     
   Declare @siCodEst    Smallint,     
           @bActivo     Bit,
           @psiCodGru   Smallint, 
           @psiCodUOr   Smallint 
    
   Set @siCodEst  = 1;     
   Set @bActivo   = 1; 
   Set @psiCodGru =7820;
   Set @psiCodUOr =270; 
     
   
   DECLARE @columnas nvarchar(max)
   Set @columnas = ''
   Select @columnas =  coalesce(@columnas + '<li>'+ vNomCoordinador    + '</li>', '')
	From (Select distinct   (Upper(Rtrim(vApePat)) + ' ' + Upper(Rtrim(vApeMat)) + ', ' + Upper(Rtrim(vNombre) )) As vNomCoordinador
	 From SIAT001.dbo.SGUsuGru        (NoLock) As a  
   Inner Join SIAT001.dbo.SGMaeUsu  (NoLock) As b On b.siCodUsu = a.siCodUsu And b.bActivo = @bActivo  
   Inner Join SIAT001.dbo.SGUOrUsu  (NoLock) As c On c.siCodUsu = b.siCodUsu And c.siCodUOr = @psiCodUOr And c.siCodEst = @siCodEst  
      Where a.siCodGru = @psiCodGru   
	) As DTM		
	Set @columnas = left(@columnas,LEN(@columnas))	
	select @columnas	
   
   DECLARE @columnas nvarchar(max)
   Set @columnas = ''
   Select @columnas =  coalesce(@columnas + '<li>'+ vNomProceso  + '</li>', '')
	From (select distinct  vNomProceso from CSITabProceso) as DTM		
	Set @columnas = left(@columnas,LEN(@columnas))	
	select @columnas	




   Select   
       cNomUsu =  Upper(Rtrim(vApePat)) + ' ' + Upper(Rtrim(vApeMat)) + ', ' + Upper(Rtrim(vNombre))  
   From SIAT001.dbo.SGUsuGru        (NoLock) As a  
   Inner Join SIAT001.dbo.SGMaeUsu  (NoLock) As b On b.siCodUsu = a.siCodUsu And b.bActivo = @bActivo  
   Inner Join SIAT001.dbo.SGUOrUsu  (NoLock) As c On c.siCodUsu = b.siCodUsu And c.siCodUOr = @psiCodUOr And c.siCodEst = @siCodEst  
      Where a.siCodGru = @psiCodGru  
   Order By cNomUsu  
select * from  SIAT001.dbo.SGMaeUsu  
