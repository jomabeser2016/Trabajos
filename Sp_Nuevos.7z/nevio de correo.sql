
spCSI_Inconsistencia_Asignacion_DevolverDatosEnvioCorreo '<DatosAsignacion><row>
                           <iCodCasuistica>1</iCodCasuistica>
                           <iTipo>1</iTipo>
                           <siCodUsuColaborador>11969</siCodUsuColaborador>
                           <siCodUsuCoordinador>10616</siCodUsuCoordinador>
                           <iCanInconsistencias>1</iCanInconsistencias>
                           <vObservacion>Correo Pruebas no tomar en cuenta</vObservacion>
                           <sdFechaAsignacion>12/11/2016</sdFechaAsignacion>
                           </row>
                           <row>
                           <iCodCasuistica>1</iCodCasuistica>
                           <iTipo>1</iTipo>
                           <siCodUsuColaborador>11969</siCodUsuColaborador>
                           <siCodUsuCoordinador>10616</siCodUsuCoordinador>
                           <iCanInconsistencias>1</iCanInconsistencias>
                           <vObservacion>Correo Pruebas no tomar en cuenta</vObservacion>
                            <sdFechaAsignacion>12/11/2016</sdFechaAsignacion>
                           </row></DatosAsignacion>'

Alter Procedure spCSI_Inconsistencia_Asignacion_DevolverDatosEnvioCorreo
   @pxDatosColaborador Xml
As
Begin

   Set NoCount On
   Declare  @bActivo Bit
   Set      @bActivo=1;
   Create Table #tmpDatosAsignacion
   (
      iCodCasuistica          Int ,
      siCodUsuColaborador     Smallint,
      iCanInconsistencias     Int,
      siCodUsuCoordinador     Smallint,
      iTipo                   Int,
      vObservacion            Varchar(200),
      sdFechaAsignacion       SmallDatetime
      
   ) 
   Insert Into  #tmpDatosAsignacion
     Select	
         doc.col.value('iCodCasuistica[1]', 'Int')                As iCodCasuistica,
         doc.col.value('siCodUsuColaborador[1]', 'Smallint')      As siCodUsuColaborador,
         doc.col.value('iCanInconsistencias[1]', 'Int')           As iCanInconsistencias,
         doc.col.value('siCodUsuCoordinador[1]', 'Smallint')      As siCodUsuCoordinador,
         doc.col.value('iTipo[1]', 'int')                         As siCodUsuCoordinador,
         doc.col.value('vObservacion[1]', 'Varchar(400)')         As vObservacion,
         doc.col.value('sdFechaAsignacion[1]', 'SmallDatetime')   As sdFechaAsignacion
         
         
   From @pxDatosColaborador.nodes('/DatosAsignacion/row') doc(col)
   
   Declare  @vNomDominio            Varchar(100)
   Declare  @vEncabezadoAsig        Varchar(100)
   Declare  @vEncabezadoReasig      Varchar(100)
   Declare  @siCodParamEncaAsig     Smallint
   Declare  @siCodParamEncaReasig   Smallint
   Declare  @siCodParamDom          Smallint
   Declare  @siServSMTP             Smallint
   Declare  @vServSMTP              Varchar(100)
   
   Set      @siCodParamDom          =8
   Set      @siCodParamEncaAsig     =7
   Set      @siCodParamEncaReasig   =9
   Set      @siServSMTP             =1
   
   Set @vNomDominio        = (  Select vTipTexParametro From dbo.CSITabParametro Where siCodParametro=@siCodParamDom)
   Set @vEncabezadoAsig    = (  Select vTipTexParametro From dbo.CSITabParametro Where siCodParametro=@siCodParamEncaAsig)
   Set @vEncabezadoReasig  = (  Select vTipTexParametro From dbo.CSITabParametro Where siCodParametro=@siCodParamEncaReasig)
   Set @vServSMTP          = (  Select vTipTexParametro From dbo.CSITabParametro Where siCodParametro=@siServSMTP)
                     
   Select   mu.siCodUsu,
            Rtrim(mu.cLogUsu)+@vNomDominio  As vCorreoColaborador,
            Rtrim(muc.cLogUsu)+@vNomDominio As vCorreoCoordinador,
            'apoyo511@SAT.GOB.PE,apoyo512@SAT.GOB.PE,apoyo515@SAT.GOB.PE,luimeneses@SAT.GOB.PE,' +Rtrim(muc.cLogUsu)+@vNomDominio As vCorreoSupervisor,
            mc.iCodCasuistica,
            mc.vNomCasuistica,
            ta.iCanInconsistencias,
            vNomUsuColaborador   =  Rtrim(mu.vApePat)    + ' '    + Rtrim(mu.vApeMat)  + ', '   + Rtrim(mu.vNombre),
            vNomCoordinador      =  Rtrim(muc.vApePat)   + ' '    + Rtrim(muc.vApeMat) + ', '   + Rtrim(muc.vNombre),
            Case ta.iTipo
               When 1 Then @vEncabezadoAsig     + ' ' + IsNull(mc.vNomAbreviado,'')    
               When 2 Then @vEncabezadoReasig   + ' ' + IsNull(mc.vNomAbreviado,'') 
            End As vEncabezado,
            ta.vObservacion,
            IsNull(gc.vNomGruCasuistica,'') As vNomGruCasuistica,
            IsNull(uor.vDesUOr,'') As vDesUOr,
            
            '<html>
               <body>
               <FONT FACE="tahoma" FONT size="2%">
               Estimado colaborador '+ Rtrim(mu.vApePat)    + ' '    + Rtrim(mu.vApeMat)  + ', '   + Rtrim(mu.vNombre)+ ';
               <br><br> Se informa que se le ha ' +    Case ta.iTipo 
                                                   When 1 Then 'asignado ' + CONVERT(Varchar,ta.iCanInconsistencias)+ ' inconsistencias, '
                                                   When 2 Then 'reasignado ' + CONVERT(Varchar,ta.iCanInconsistencias)+ ' inconsistencias, '
                                                   End+  'de acuerdo al siguiente detalle:</br>
               <br>
               <p>
               <b>Nombre de la Casu�stica</b>: '+  mc.vNomCasuistica +'. 
               <br><b>Unidad Org�nica</b>: ' +IsNull(uor.vDesUOr,'')+ '.</br>
               <b>Grupo de la Casu�stica</b>: '+ IsNull(gc.vNomGruCasuistica,'') +  '.</br>
               <b>Fecha de '+ Case ta.iTipo 
                                                   When 1 Then 'Asignaci�n   '
                                                   When 2 Then 'Reasignaci�n  '
                                                   End + '</b>: '+ Convert(varchar(10),ta.sdFechaAsignacion,103) + '</br>
               <b>Cantidad de Inconsistencias</b>: ' +CONVERT(Varchar,ta.iCanInconsistencias) +'</br>
               <b>Observaciones</b>: ' +ta.vObservacion+ '.</p>
               <br>
               Recuerde que para una correcta atenci�n de las inconsistencias deber� tener en cuenta las observaciones y para ello debe ingresar al MCSISAT a trav�s del siguiente link: http://webiispre01/mcsi   
               <br>
               <p>
               Atte.
               <br>'+Rtrim(muc.vApePat)   + ' '    + Rtrim(muc.vApeMat) + ', '   + Rtrim(muc.vNombre)+'</br>
               '+IsNull(uor.vDesUOr,'')+'</br>
               </FONT>
               </body>
             </html>
            ' As vCuerpo,
             Convert(varchar(10),ta.sdFechaAsignacion,103) As sdFechaAsignacion,
             @vServSMTP As vServSMTP,           
             'apoyo512@sat.gob.pe' As vRemitente  ----Rtrim(muc.cLogUsu)+@vNomDominio As vRemitente 
   From dbo.CSIMaeCasuistica mc
   Inner Join #tmpDatosAsignacion ta      On mc.iCodCasuistica=ta.iCodCasuistica
   Inner Join SIAT001.dbo.SGMaeUsu mu     On ta.siCodUsuColaborador=mu.siCodUsu  And mu.bActivo=@bActivo
   Inner Join SIAT001.dbo.SGMaeUsu muc    On ta.siCodUsuCoordinador=muc.siCodUsu And muc.bActivo=@bActivo
   Inner Join dbo.CSITabGruCasuistica gc  On mc.siCodGrupo=gc.siCodGrupo
   Left  Join dbo.CSIMovCasuisticaUOr   (NoLock) As mov On mc.iCodCasuistica = mov.iCodCasuistica And mc.siCodMun = mov.siCodMun And mov.bActivo=@bActivo
	Left  Join SIAT001.dbo.SGTabUOr      (NoLock) As uor On mov.siCodUOr = uor.siCodUOr
   
   Where mu.bActivo=@bActivo
   Drop Table #tmpDatosAsignacion
   
  Set NoCount Off
  
End


