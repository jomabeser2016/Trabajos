     
      Declare  @psiCodMun        Smallint
      Declare  @psiCodGru        Smallint   
      Declare  @psiCodUOr        Smallint 
      Declare  @bActivo          Bit
        
      Set      @psiCodMun=1
      Set      @psiCodGru=7819
      Set      @psiCodUOr=270
      Set      @bActivo   = 1;  
   
   Select   
     siSupervisor=b.sicodusu, vSupervisor =  Upper(Rtrim(vApePat)) + ' ' + Upper(Rtrim(vApeMat)) + ', ' + Upper(Rtrim(vNombre))  
   From SIAT001.dbo.SGUsuGru        (NoLock) As a  
   Inner Join SIAT001.dbo.SGMaeUsu  (NoLock) As b On b.siCodUsu = a.siCodUsu And b.bActivo = @bActivo  
   Where a.siCodGru = @psiCodGru  
   Order By cNomUsu  
   
