
Select top 1 * From dbo.CSIMaeInconsistencia Where siCodEstInconsistencia=1
Select * From dbo.CSITabEstInconsistencia

Select siCodUsu,rtrim(cLogUsu)+'@SAT.GOB.PE' As Correo from SIAT001.dbo.SGMaeUsu 
where siCodUsu='378'


--EXEC sp_configure 'show advanced option', '1'; 
--reconfigure exec sp_configure 'SQL Mail XPs', 1 reconfigure  
--blind_copy_recipients  
EXEC  msdb.dbo.sp_send_dbmail 
@profile_name='AlertaMCSI' , 
@recipients= 'apoyo512@SAT.GOB.PE',
@subject= 'Sistema de Control y Seguimiento de Inconsistencias MCSI',
@body= 'Se ha Asignado 5 inconsistencias a su Usuario'

select * from dbo.CSIMaeCasuistica